rootProject.name = "HiddenRealmCommander"
