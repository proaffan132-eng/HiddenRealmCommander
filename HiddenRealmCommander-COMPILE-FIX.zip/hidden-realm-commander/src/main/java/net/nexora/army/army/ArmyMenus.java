package net.nexora.army.army;

import net.nexora.army.config.Settings;
import net.nexora.army.model.ArmyState;
import net.nexora.army.util.Texts;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

public final class ArmyMenus implements Listener {
    private static final String MAIN = "<gold>Army Command";
    private static final String BUILD = "<gold>Choose a Structure";
    private final ArmyService army;

    public ArmyMenus(net.nexora.army.ArmyPlugin plugin, ArmyService army) { this.army = army; }

    public static void openMain(Player player, ArmyState state, Settings settings) {
        Inventory inv = Bukkit.createInventory(null, 27, Texts.parse(MAIN));
        put(inv, 10, Material.LEATHER_BOOTS, "Follow", "follow", "Deploy a visible squad that follows you");
        put(inv, 11, Material.SHIELD, "Defend Here", "defend", "Guard your current location");
        put(inv, 12, Material.IRON_SWORD, "Attack Nearest", "attack", "Order an attack on a nearby valid player");
        put(inv, 13, Material.IRON_PICKAXE, "Mine", "mine", "Assign soldiers to gather resources");
        put(inv, 14, Material.BRICKS, "Build", "build", "Choose a structure to build");
        put(inv, 15, Material.CLOCK, "Recall Army", "return", "Bring deployed soldiers home");
        put(inv, 16, Material.BOOK, "Army Statistics", "stats", "View your army status");
        ItemStack info = new ItemStack(Material.PAPER); ItemMeta meta = info.getItemMeta(); meta.displayName(Texts.parse("<yellow>Owned soldiers: <white>" + state.soldiers)); meta.lore(java.util.List.of(Texts.parse("<gray>Current task: " + state.task.label()), Texts.parse("<gray>Castles discovered: " + state.discoveredCount() + "/3"))); info.setItemMeta(meta); inv.setItem(4, info);
        player.openInventory(inv);
    }

    public static void openBuild(Player player) {
        Inventory inv = Bukkit.createInventory(null, 27, Texts.parse(BUILD));
        put(inv, 11, Material.OAK_PLANKS, "Chapel", "build:chapel", "Place a chapel");
        put(inv, 13, Material.COBBLESTONE, "Watchtower", "build:watchtower", "Place a defensive watchtower");
        put(inv, 15, Material.STONE_BRICKS, "Barracks", "build:barracks", "Place an army barracks");
        put(inv, 22, Material.COBBLESTONE_WALL, "Wall", "build:wall", "Place a defensive wall section");
        player.openInventory(inv);
    }

    private static void put(Inventory inv, int slot, Material material, String title, String action, String lore) {
        ItemStack item = new ItemStack(material); ItemMeta meta = item.getItemMeta();
        meta.displayName(Texts.parse("<gold>" + title)); meta.lore(java.util.List.of(Texts.parse("<gray>" + lore)));
        // Store the action as a namespaced string using the inventory's plugin-independent key.
        meta.setLocalizedName("hrc:" + action); item.setItemMeta(meta); inv.setItem(slot, item);
    }

    @EventHandler public void onClick(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player player)) return;
        String title = net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer.plainText().serialize(event.getView().title());
        if (!title.equals("Army Command") && !title.equals("Choose a Structure")) return;
        event.setCancelled(true);
        if (event.getClickedInventory() == null || event.getClickedInventory() != event.getView().getTopInventory()) return;
        ItemStack item = event.getCurrentItem(); if (item == null || !item.hasItemMeta()) return;
        String raw = item.getItemMeta().getLocalizedName(); if (raw == null || !raw.startsWith("hrc:")) return;
        String action = raw.substring(4); player.closeInventory();
        switch (action) {
            case "follow" -> army.follow(player);
            case "defend" -> army.defendHere(player);
            case "attack" -> army.attackNearest(player);
            case "mine" -> army.mine(player);
            case "build" -> army.openBuild(player);
            case "return" -> army.returnArmy(player);
            case "stats" -> army.stats(player);
            case "build:chapel" -> army.beginBuild(player, "chapel");
            case "build:watchtower" -> army.beginBuild(player, "watchtower");
            case "build:barracks" -> army.beginBuild(player, "barracks");
            case "build:wall" -> army.beginBuild(player, "wall");
            default -> Texts.send(player, "<red>Unknown menu action.");
        }
    }
}
