package net.nexora.army.model;

import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public final class ArmyState {
    public final UUID playerId;
    public int soldiers;
    public TaskType task = TaskType.IDLE;
    public String taskWorld;
    public int taskX;
    public int taskY;
    public int taskZ;
    public String taskTarget;
    public String taskExtra;
    public boolean defenseActive;
    public String defenseWorld;
    public int defenseX;
    public int defenseY;
    public int defenseZ;
    public int defenseRadius = 24;
    public final Set<UUID> trusted = ConcurrentHashMap.newKeySet();
    public final Set<String> discovered = ConcurrentHashMap.newKeySet();

    public ArmyState(UUID playerId) {
        this.playerId = playerId;
    }

    public int discoveredCount() {
        return discovered.size();
    }
}
