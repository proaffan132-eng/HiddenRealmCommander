package net.nexora.army.castle;

import net.nexora.army.model.Pos;

import java.util.List;

/** Celestial Citadel: an end-stone platform, purpur spire, and a relic chamber. */
public final class EndCitadel {
    private EndCitadel() {
    }

    public static StructurePlan create() {
        Brush brush = new Brush();
        String brick = "end_stone_bricks";
        String purpur = "purpur_block";
        String pillar = "purpur_pillar[axis=y]";
        String slab = "end_stone_brick_slab[type=bottom]";
        String stairs = "purpur_stairs";
        String quartz = "smooth_quartz";

        brush.fill(-30, -2, -30, 30, -1, 30, "end_stone");
        brush.fill(-26, 0, -26, 26, 0, 26, brick);
        for (int x = -24; x <= 24; x += 6) {
            for (int z = -24; z <= 24; z += 6) {
                if (Math.abs(x) > 16 || Math.abs(z) > 16) {
                    brush.fill(x, 1, z, x + 1, 14, z + 1, pillar);
                    brush.set(x, 15, z, "end_rod[facing=up]");
                    brush.set(x, 16, z, "sea_lantern");
                }
            }
        }
        brush.fill(-2, 0, 16, 2, 0, 26, quartz);
        brush.fill(-26, 0, -2, -16, 0, 2, quartz);
        brush.fill(16, 0, -2, 26, 0, 2, quartz);
        brush.fill(-2, 0, -26, 2, 0, -16, quartz);

        brush.air(-14, 1, -14, 14, 16, 14);
        brush.hollow(-15, 0, -15, 15, 18, 15, brick);
        brush.air(-14, 1, -14, 14, 16, 14);
        brush.air(-2, 1, 15, 2, 5, 15);
        brush.fill(-15, 0, -15, 15, 0, 15, purpur);
        for (int i = -12; i <= 12; i += 6) {
            brush.fill(i, 1, -14, i, 16, -14, pillar);
            brush.fill(i, 1, 14, i, 16, 14, pillar);
            brush.fill(-14, 1, i, -14, 16, i, pillar);
            brush.fill(14, 1, i, 14, 16, i, pillar);
        }
        brush.fill(-10, 8, -10, 10, 8, 10, "purpur_slab[type=bottom]");
        brush.air(-2, 9, 14, 2, 12, 14);
        for (int y = 1; y <= 12; y++) {
            brush.set(12, y, 0, "ladder[facing=west]");
        }
        for (int y = 3; y <= 14; y += 3) {
            brush.set(-6, y, 15, "tinted_glass");
            brush.set(6, y, 15, "tinted_glass");
            brush.set(-15, y, -6, "tinted_glass");
            brush.set(-15, y, 6, "tinted_glass");
            brush.set(15, y, -6, "tinted_glass");
            brush.set(15, y, 6, "tinted_glass");
            brush.set(-6, y, -15, "end_rod[facing=north]");
            brush.set(6, y, -15, "end_rod[facing=north]");
        }
        brush.squareRoof(0, 0, 19, 10, stairs, quartz);
        brush.fill(-1, 29, -1, 1, 34, 1, pillar);
        brush.set(0, 35, 0, "sea_lantern");
        brush.set(0, 36, 0, "end_rod[facing=up]");

        brush.hollow(-6, 1, -8, 6, 7, 2, purpur);
        brush.air(-5, 2, -7, 5, 6, 1);
        brush.air(0, 2, 2, 0, 4, 2);
        brush.fill(-2, 2, -4, 2, 2, -2, "crying_obsidian");
        brush.set(0, 3, -3, "dragon_egg");
        brush.set(0, 3, -6, "end_rod[facing=up]");
        brush.set(0, 4, 0, "ochre_froglight");
        brush.fill(-4, 2, -7, -3, 4, -6, "bookshelf");
        brush.fill(3, 2, -7, 4, 4, -6, "bookshelf");

        brush.hollow(-7, -6, -12, 7, -2, -2, brick);
        brush.air(-6, -5, -11, 6, -3, -3);
        brush.fill(-7, -6, -12, 7, -6, -2, quartz);
        for (int step = 0; step <= 6; step++) {
            brush.air(-2, -step, 6 - step, 2, 1 - step, 8 - step);
            brush.set(0, -step, 6 - step, "purpur_stairs[facing=north,half=bottom,shape=straight]");
        }
        Pos chestA = new Pos(-5, -5, -10);
        Pos chestB = new Pos(5, -5, -10);
        Pos chestC = new Pos(0, -5, -5);
        brush.set(chestA.x(), chestA.y(), chestA.z(), "chest[facing=south,type=single]");
        brush.set(chestB.x(), chestB.y(), chestB.z(), "chest[facing=south,type=single]");
        brush.set(chestC.x(), chestC.y(), chestC.z(), "chest[facing=north,type=single]");
        brush.fill(-1, -5, -8, 1, -5, -7, "amethyst_block");

        brush.fill(18, 1, -1, 22, 2, 1, "chorus_flower");
        brush.air(15, 1, -1, 17, 2, 1);
        brush.set(-20, 1, -20, "chorus_flower");
        brush.set(20, 1, -20, "chorus_flower");
        brush.set(-20, 1, 20, "chorus_flower");
        brush.set(20, 1, 20, "chorus_flower");

        return StructurePlan.of("Celestial Citadel", brush, new Pos(0, 3, -3), "dragon_egg",
                List.of(chestA, chestB, chestC));
    }
}
