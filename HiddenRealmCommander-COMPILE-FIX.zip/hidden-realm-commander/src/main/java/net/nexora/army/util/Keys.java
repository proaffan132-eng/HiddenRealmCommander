package net.nexora.army.util;

import org.bukkit.NamespacedKey;
import org.bukkit.plugin.Plugin;

public final class Keys {
    public final NamespacedKey owner;
    public final NamespacedKey soldierId;
    public final NamespacedKey role;
    public final NamespacedKey action;

    public Keys(Plugin plugin) {
        owner = new NamespacedKey(plugin, "owner");
        soldierId = new NamespacedKey(plugin, "soldier_id");
        role = new NamespacedKey(plugin, "role");
        action = new NamespacedKey(plugin, "gui_action");
    }
}
