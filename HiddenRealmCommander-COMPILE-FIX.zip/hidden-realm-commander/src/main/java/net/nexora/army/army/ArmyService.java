package net.nexora.army.army;

import net.nexora.army.castle.CastleBlueprints;
import net.nexora.army.castle.StructurePlan;
import net.nexora.army.config.Settings;
import net.nexora.army.db.Repository;
import net.nexora.army.model.ArmyState;
import net.nexora.army.model.Pos;
import net.nexora.army.model.Realm;
import net.nexora.army.model.TaskType;
import net.nexora.army.util.Texts;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.entity.Mob;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.java.JavaPlugin;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;

public final class ArmyService implements SoldierManager.TargetRules {
    private final JavaPlugin plugin;
    private final Settings settings;
    private final Repository repository;
    private final SoldierManager soldiers;
    private final ProtectionHook protection;
    private final Map<UUID, Selection> selections = new HashMap<>();
    private final Map<UUID, PendingAttack> pendingAttacks = new HashMap<>();
    private final Map<UUID, Long> nextMine = new HashMap<>();
    private final Map<UUID, List<BuildBlock>> buildQueues = new HashMap<>();
    private final Map<String, Long> hitTimes = new HashMap<>();

    public ArmyService(JavaPlugin plugin, Settings settings, Repository repository, SoldierManager soldiers, ProtectionHook protection) {
        this.plugin = plugin;
        this.settings = settings;
        this.repository = repository;
        this.soldiers = soldiers;
        this.protection = protection;
    }

    public ArmyState state(Player player) {
        return repository.state(player.getUniqueId());
    }

    public void open(Player player) {
        ArmyMenus.openMain(player, state(player), settings);
    }

    public void tick() {
        soldiers.tick(this);
        long now = System.currentTimeMillis();
        for (ArmyState state : repository.armies()) {
            if (state.task == TaskType.MINE && now >= nextMine.getOrDefault(state.playerId, 0L)) {
                nextMine.put(state.playerId, now + settings.mineCycleSeconds * 1000L);
                mineCycle(state);
            } else if (state.task == TaskType.BUILD) {
                buildCycle(state);
            }
        }
        if (hitTimes.size() > 4000) {
            hitTimes.entrySet().removeIf(entry -> now - entry.getValue() > 10_000);
        }
    }

    public void follow(Player player) {
        ArmyState state = requireArmy(player);
        if (state == null) {
            return;
        }
        clearSelection(player);
        soldiers.despawnAll(player.getUniqueId());
        state.task = TaskType.FOLLOW;
        state.defenseActive = false;
        state.taskWorld = player.getWorld().getName();
        state.taskX = player.getLocation().getBlockX();
        state.taskY = player.getLocation().getBlockY();
        state.taskZ = player.getLocation().getBlockZ();
        state.taskTarget = null;
        if (!save(player, state)) {
            return;
        }
        int spawned = soldiers.spawn(player, "follow", player.getLocation(), settings.visibleFollow, 48);
        Texts.send(player, "<green>Your army is following you. <white>" + spawned + "</white> soldiers are visible. <gray>" + assigned(state) + " are assigned, <white>" + available(state) + "</white> stay in reserve.");
    }

    public void defendHere(Player player) {
        setDefense(player, player.getLocation(), false);
    }

    public void beginDefendSelect(Player player) {
        if (requireArmy(player) == null) {
            return;
        }
        selections.put(player.getUniqueId(), new Selection("defend", null, expires()));
        player.closeInventory();
        Texts.send(player, "<yellow>Right-click the block that should be the center of your defense. This expires shortly.");
    }

    public void setDefense(Player player, Location location, boolean fromSelection) {
        ArmyState state = requireArmy(player);
        if (state == null || location.getWorld() == null) {
            return;
        }
        if (settings.respectWorldGuard && protection.hasRegion(location) && !player.hasPermission("army.admin")) {
            Texts.send(player, "<red>That spot is inside a protected region.");
            return;
        }
        clearSelection(player);
        soldiers.despawnAll(player.getUniqueId());
        int radius = state.defenseRadius <= 0 ? settings.defaultRadius : state.defenseRadius;
        radius = clampRadius(radius);
        state.defenseActive = true;
        state.defenseWorld = location.getWorld().getName();
        state.defenseX = location.getBlockX();
        state.defenseY = location.getBlockY();
        state.defenseZ = location.getBlockZ();
        state.defenseRadius = radius;
        state.task = TaskType.DEFEND;
        state.taskWorld = state.defenseWorld;
        state.taskX = state.defenseX;
        state.taskY = state.defenseY;
        state.taskZ = state.defenseZ;
        state.taskTarget = null;
        if (!save(player, state)) {
            return;
        }
        int spawned = soldiers.spawn(player, "defend", location, settings.visibleDefend, radius);
        Texts.send(player, "<green>Guards are holding <white>" + state.defenseX + " " + state.defenseY + " " + state.defenseZ
                + "</white> in <white>" + state.defenseWorld + "</white>. Radius <white>" + radius + "</white>. Visible guards: <white>" + spawned + "</white>.");
        if (!fromSelection) {
            Texts.send(player, "<gray>Right-click a new center with /army defend set. Trusted players are not attacked.");
        }
    }

    public void setRadius(Player player, int radius) {
        ArmyState state = requireArmy(player);
        if (state == null) {
            return;
        }
        int clamped = clampRadius(radius);
        state.defenseRadius = clamped;
        if (state.defenseActive) {
            Location location = defenseLocation(state);
            if (location != null) {
                soldiers.despawnAll(player.getUniqueId());
                soldiers.spawn(player, "defend", location, settings.visibleDefend, clamped);
            }
        }
        if (!save(player, state)) {
            return;
        }
        if (clamped != radius) {
            Texts.send(player, "<yellow>Radius clamped to <white>" + clamped + "</white>. Allowed range is " + settings.minRadius + " to " + settings.maxRadius + ".");
        } else {
            Texts.send(player, "<green>Defense radius set to <white>" + clamped + "</white> blocks.");
        }
    }

    public void stopDefense(Player player) {
        ArmyState state = state(player);
        state.defenseActive = false;
        if (state.task == TaskType.DEFEND) {
            state.task = TaskType.IDLE;
        }
        soldiers.despawnAll(player.getUniqueId());
        clearSelection(player);
        if (!save(player, state)) {
            return;
        }
        Texts.send(player, "<yellow>Defense is stopped. Guards have returned to your virtual army.");
    }

    public void attackNearest(Player player) {
        Player target = nearestEnemy(player);
        if (target == null) {
            Texts.send(player, "<red>No valid enemy is close enough. Use /army attack <player> for someone within " + settings.attackOrderDistance + " blocks.");
            return;
        }
        PendingAttack pending = pendingAttacks.get(player.getUniqueId());
        long now = System.currentTimeMillis();
        if (pending == null || !pending.target.equals(target.getUniqueId()) || pending.expires < now) {
            pendingAttacks.put(player.getUniqueId(), new PendingAttack(target.getUniqueId(), now + 8000));
            Texts.send(player, "<yellow>Click attack again to send your army after <white>" + target.getName() + "</white>.");
            return;
        }
        pendingAttacks.remove(player.getUniqueId());
        attack(player, target);
    }

    public void attack(Player player, Player target) {
        if (!player.hasPermission("army.attack")) {
            Texts.send(player, "<red>You cannot order an attack.");
            return;
        }
        ArmyState state = requireArmy(player);
        if (state == null) {
            return;
        }
        String problem = attackProblem(player, target);
        if (problem != null) {
            Texts.send(player, problem);
            return;
        }
        soldiers.despawnAll(player.getUniqueId());
        state.defenseActive = false;
        state.task = TaskType.ATTACK;
        state.taskWorld = player.getWorld().getName();
        state.taskX = player.getLocation().getBlockX();
        state.taskY = player.getLocation().getBlockY();
        state.taskZ = player.getLocation().getBlockZ();
        state.taskTarget = target.getUniqueId().toString();
        if (!save(player, state)) {
            return;
        }
        Location origin = player.getLocation();
        int spawned = soldiers.spawn(player, "attack", origin, settings.visibleAttack, settings.attackLeash);
        soldiers.setAttackTarget(player.getUniqueId(), target.getUniqueId());
        Texts.send(player, "<red>Your army is attacking <white>" + target.getName() + "</white>. Visible soldiers: <white>" + spawned + "</white>. They will not chase past " + settings.attackLeash + " blocks.");
    }

    public void mine(Player player) {
        ArmyState state = requireArmy(player);
        if (state == null) {
            return;
        }
        Location location = player.getLocation();
        if (!workSiteAllowed(player, location)) {
            return;
        }
        soldiers.despawnAll(player.getUniqueId());
        state.defenseActive = false;
        state.task = TaskType.MINE;
        state.taskWorld = location.getWorld().getName();
        state.taskX = location.getBlockX();
        state.taskY = location.getBlockY();
        state.taskZ = location.getBlockZ();
        state.taskTarget = null;
        if (!save(player, state)) {
            return;
        }
        nextMine.put(player.getUniqueId(), System.currentTimeMillis() + 1000L);
        int spawned = soldiers.spawn(player, "mine", location, settings.visibleMine, 12);
        int assigned = Math.min(state.soldiers, settings.assignedMine);
        Texts.send(player, "<aqua>Mining has started. <white>" + assigned + "</white> soldiers are assigned, <white>" + spawned
                + "</white> are visible. " + (settings.simulateMining ? "They deliver materials without breaking the land." : "They only break natural stone."));
    }

    public void openBuild(Player player) {
        if (requireArmy(player) == null) {
            return;
        }
        ArmyMenus.openBuild(player);
    }

    public void beginBuild(Player player, String template) {
        if (CastleBlueprints.template(template) == null) {
            Texts.send(player, "<red>Unknown building template.");
            return;
        }
        if (requireArmy(player) == null) {
            return;
        }
        selections.put(player.getUniqueId(), new Selection("build", template, expires()));
        player.closeInventory();
        Texts.send(player, "<yellow>Right-click the corner block. The <white>" + template + "</white> grows east and south from that block.");
    }

    public boolean handleSelection(Player player, Block block) {
        Selection selection = selections.get(player.getUniqueId());
        if (selection == null) {
            return false;
        }
        if (selection.expires < System.currentTimeMillis()) {
            selections.remove(player.getUniqueId());
            Texts.send(player, "<red>That selection expired.");
            return true;
        }
        if ("defend".equals(selection.mode)) {
            setDefense(player, block.getLocation(), true);
            return true;
        }
        if ("build".equals(selection.mode)) {
            confirmBuild(player, block.getLocation(), selection.template);
            return true;
        }
        return false;
    }

    public void confirmBuild(Player player, Location location, String template) {
        ArmyState state = requireArmy(player);
        StructurePlan plan = CastleBlueprints.template(template);
        if (state == null || plan == null || location.getWorld() == null) {
            return;
        }
        if (!workSiteAllowed(player, location)) {
            return;
        }
        World world = location.getWorld();
        List<BuildBlock> queue = new ArrayList<>();
        for (var entry : plan.blocks.entrySet()) {
            if ("air".equals(entry.getValue())) {
                continue;
            }
            Pos pos = entry.getKey();
            int x = location.getBlockX() + pos.x();
            int y = location.getBlockY() + pos.y();
            int z = location.getBlockZ() + pos.z();
            Material existing = world.getBlockAt(x, y, z).getType();
            if (Settings.isArtificial(existing)) {
                Texts.send(player, "<red>That spot already contains player blocks. Pick open ground.");
                return;
            }
            queue.add(new BuildBlock(x, y, z, entry.getValue()));
        }
        if (queue.isEmpty()) {
            Texts.send(player, "<red>That template has nothing to place.");
            return;
        }
        clearSelection(player);
        soldiers.despawnAll(player.getUniqueId());
        state.defenseActive = false;
        state.task = TaskType.BUILD;
        state.taskWorld = world.getName();
        state.taskX = location.getBlockX();
        state.taskY = location.getBlockY();
        state.taskZ = location.getBlockZ();
        state.taskExtra = template;
        buildQueues.put(player.getUniqueId(), queue);
        if (!save(player, state)) {
            return;
        }
        int spawned = soldiers.spawn(player, "build", location, settings.visibleBuild, 16);
        Texts.send(player, "<green>Builders started the <white>" + template + "</white>. <white>" + spawned + "</white> are on site, placing " + settings.buildBlocksPerCycle + " blocks at a time.");
    }

    public void returnArmy(Player player) {
        ArmyState state = state(player);
        if (state.soldiers <= 0) {
            Texts.send(player, "<red>You have no soldiers to recall.");
            return;
        }
        state.task = TaskType.RETURN;
        state.defenseActive = false;
        state.taskTarget = null;
        buildQueues.remove(player.getUniqueId());
        soldiers.markReturning(player.getUniqueId());
        if (!save(player, state)) {
            return;
        }
        Texts.send(player, "<green>Your army is returning. They will fold back into the reserve as they arrive.");
        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            if (state.task == TaskType.RETURN) {
                soldiers.despawnAll(player.getUniqueId());
                state.task = TaskType.IDLE;
                save(player, state);
                if (player.isOnline()) {
                    Texts.send(player, "<green>The army is home. <white>" + state.soldiers + "</white> soldiers are available.");
                }
            }
        }, 160L);
    }

    public void dismiss(Player player) {
        ArmyState state = state(player);
        soldiers.despawnAll(player.getUniqueId());
        buildQueues.remove(player.getUniqueId());
        clearSelection(player);
        state.task = TaskType.IDLE;
        state.defenseActive = false;
        state.taskTarget = null;
        if (!save(player, state)) {
            return;
        }
        Texts.send(player, "<yellow>Deployed soldiers were dismissed. Your virtual army is unchanged: <white>" + state.soldiers + "</white>.");
    }

    public void trust(Player player, Player target, boolean add) {
        if (target.getUniqueId().equals(player.getUniqueId())) {
            Texts.send(player, "<red>You cannot trust yourself.");
            return;
        }
        try {
            repository.trust(player.getUniqueId(), target.getUniqueId(), add);
        } catch (SQLException ex) {
            Texts.send(player, "<red>Could not update your trust list.");
            plugin.getLogger().warning(ex.getMessage());
            return;
        }
        Texts.send(player, add
                ? "<green><white>" + target.getName() + "</white> is trusted. Your guards will ignore them."
                : "<yellow><white>" + target.getName() + "</white> is no longer trusted.");
    }

    public void stats(Player player) {
        ArmyState state = state(player);
        Texts.send(player, "<gold>Army statistics");
        Texts.send(player, "<gray>Owned soldiers: <white>" + state.soldiers);
        Texts.send(player, "<gray>Castles discovered: <white>" + state.discoveredCount() + "/3</white> <dark_gray>(" + discoveredNames(state) + ")");
        Texts.send(player, "<gray>Status: <white>" + state.task.label());
        Texts.send(player, "<gray>Visible now: <white>" + soldiers.alive(player.getUniqueId()));
        Texts.send(player, "<gray>Assigned to the task: <white>" + assigned(state));
        Texts.send(player, "<gray>Available: <white>" + available(state));
        if (state.defenseWorld != null) {
            Texts.send(player, "<gray>Defense point: <white>" + (state.defenseActive ? "active" : "saved") + "</white> at <white>"
                    + state.defenseX + " " + state.defenseY + " " + state.defenseZ + "</white> radius <white>" + state.defenseRadius + "</white> in " + state.defenseWorld);
        } else {
            Texts.send(player, "<gray>Defense point: <white>not set");
        }
        Texts.send(player, "<gray>Trusted players: <white>" + state.trusted.size());
        Texts.send(player, "<gray>Server soldiers visible: <white>" + soldiers.alive() + "/" + settings.maxActiveServer);
    }

    public void help(Player player) {
        Texts.send(player, "<gold>Army commands");
        Texts.send(player, "<yellow>/army <gray>— open the command GUI");
        Texts.send(player, "<yellow>/army follow <gray>— visible soldiers follow you");
        Texts.send(player, "<yellow>/army defend <gray>— defend your current spot");
        Texts.send(player, "<yellow>/army defend set <gray>— right-click a defense center");
        Texts.send(player, "<yellow>/army defend radius <blocks> <gray>— resize the guard radius");
        Texts.send(player, "<yellow>/army defend stop <gray>— send the guards home");
        Texts.send(player, "<yellow>/army attack <player> <gray>— attack a nearby valid player");
        Texts.send(player, "<yellow>/army mine <gray>— gather at your location");
        Texts.send(player, "<yellow>/army build <gray>— choose a structure, then right-click");
        Texts.send(player, "<yellow>/army return <gray>— recall everyone");
        Texts.send(player, "<yellow>/army trust <player> <gray>and <yellow>/army untrust <player>");
        Texts.send(player, "<yellow>/army stats <gray>and <yellow>/army help");
    }

    public void onJoin(Player player) {
        ArmyState state = state(player);
        if (state.task == TaskType.ATTACK || state.task == TaskType.BUILD || state.task == TaskType.RETURN) {
            state.task = TaskType.IDLE;
            save(player, state);
        }
        if (state.task == TaskType.FOLLOW && !settings.resumeFollow) {
            state.task = TaskType.IDLE;
            save(player, state);
        }
        if (state.task == TaskType.FOLLOW && settings.resumeFollow) {
            soldiers.spawn(player, "follow", player.getLocation(), settings.visibleFollow, 48);
        }
        if (state.defenseActive && settings.resumeDefense) {
            Location location = defenseLocation(state);
            if (location != null && soldiers.aliveRole(player.getUniqueId(), "defend") == 0) {
                state.task = TaskType.DEFEND;
                soldiers.spawn(player, "defend", location, settings.visibleDefend, state.defenseRadius);
                save(player, state);
            }
        }
    }

    public void onQuit(Player player) {
        clearSelection(player);
        pendingAttacks.remove(player.getUniqueId());
        boolean keep = settings.keepGuardsOnQuit && state(player).defenseActive;
        soldiers.despawn(player.getUniqueId(), keep);
    }

    public boolean recentlyHit(UUID soldierId, UUID victimId) {
        long now = System.currentTimeMillis();
        String key = soldierId + ":" + victimId;
        Long last = hitTimes.get(key);
        if (last != null && now - last < settings.hitDelayMs) {
            return true;
        }
        hitTimes.put(key, now);
        return false;
    }

    public boolean canHurt(Player victim, UUID ownerId, Location where) {
        if (victim == null || ownerId == null) {
            return false;
        }
        if (settings.protectOwner && victim.getUniqueId().equals(ownerId)) {
            return false;
        }
        ArmyState state = repository.state(ownerId);
        if (settings.protectTrusted && state.trusted.contains(victim.getUniqueId())) {
            return false;
        }
        if (settings.ignoreCreative && (victim.getGameMode() == GameMode.CREATIVE || victim.getGameMode() == GameMode.SPECTATOR)) {
            return false;
        }
        if (settings.respectWorldPvp && where.getWorld() != null && !where.getWorld().getPVP()) {
            return false;
        }
        if (settings.respectWorldGuard && protection.deniesPvp(victim.getLocation())) {
            return false;
        }
        return true;
    }

    @Override
    public Player intruder(UUID owner, Location home) {
        if (owner == null || home.getWorld() == null) {
            return null;
        }
        ArmyState state = repository.state(owner);
        if (!state.defenseActive) {
            return null;
        }
        double radius = state.defenseRadius;
        Player closest = null;
        double best = radius * radius;
        for (Player player : home.getWorld().getPlayers()) {
            if (!canHurt(player, owner, player.getLocation())) {
                continue;
            }
            double distance = player.getLocation().distanceSquared(home);
            if (distance <= best) {
                best = distance;
                closest = player;
            }
        }
        return closest;
    }

    @Override
    public boolean allowAttack(Mob mob, Player target, Location leash, int leashDistance) {
        UUID owner = soldiers.ownerOf(mob);
        if (owner == null || !canHurt(target, owner, target.getLocation())) {
            return false;
        }
        if (leash.getWorld() == null || target.getWorld() != leash.getWorld()) {
            return false;
        }
        return target.getLocation().distanceSquared(leash) <= (long) leashDistance * leashDistance;
    }

    private void mineCycle(ArmyState state) {
        Player player = Bukkit.getPlayer(state.playerId);
        if (player == null || !player.isOnline()) {
            return;
        }
        int assigned = Math.min(state.soldiers, settings.assignedMine);
        if (assigned <= 0) {
            return;
        }
        World world = Bukkit.getWorld(state.taskWorld == null ? "" : state.taskWorld);
        if (world == null) {
            return;
        }
        Location center = new Location(world, state.taskX, state.taskY, state.taskZ);
        if (settings.respectWorldGuard && protection.hasRegion(center)) {
            return;
        }
        if (!settings.simulateMining) {
            breakNatural(world, center);
            return;
        }
        int amount = (int) Math.min(settings.mineMaxItems, Math.max(1, Math.round(Math.sqrt(assigned) / 10.0)));
        Material material = switch (world.getEnvironment()) {
            case NETHER -> Material.NETHERRACK;
            case THE_END -> Material.END_STONE;
            default -> Material.COBBLESTONE;
        };
        give(player, new ItemStack(material, amount));
        ThreadLocalRandom random = ThreadLocalRandom.current();
        if (random.nextDouble() < settings.ironChance) {
            give(player, new ItemStack(Material.RAW_IRON, 1));
        }
        if (random.nextDouble() < settings.goldChance) {
            give(player, new ItemStack(Material.RAW_GOLD, 1));
        }
        world.playSound(center, org.bukkit.Sound.BLOCK_STONE_BREAK, 0.6f, 0.8f);
    }

    private void breakNatural(World world, Location center) {
        int broken = 0;
        int radius = 5;
        for (int tries = 0; tries < 40 && broken < settings.realMineBlocks; tries++) {
            int x = center.getBlockX() + ThreadLocalRandom.current().nextInt(-radius, radius + 1);
            int y = center.getBlockY() + ThreadLocalRandom.current().nextInt(-2, 3);
            int z = center.getBlockZ() + ThreadLocalRandom.current().nextInt(-radius, radius + 1);
            Block block = world.getBlockAt(x, y, z);
            if (!settings.realBreakable.contains(block.getType()) || Settings.isArtificial(block.getType())) {
                continue;
            }
            if (settings.respectWorldGuard && protection.hasRegion(block.getLocation())) {
                continue;
            }
            block.breakNaturally();
            broken++;
        }
    }

    private void buildCycle(ArmyState state) {
        List<BuildBlock> queue = buildQueues.get(state.playerId);
        if (queue == null || queue.isEmpty()) {
            state.task = TaskType.IDLE;
            soldiers.despawnAll(state.playerId);
            try {
                repository.saveArmy(state);
            } catch (SQLException ex) {
                plugin.getLogger().warning(ex.getMessage());
            }
            return;
        }
        World world = Bukkit.getWorld(state.taskWorld == null ? "" : state.taskWorld);
        if (world == null) {
            return;
        }
        int placed = 0;
        Iterator<BuildBlock> iterator = queue.iterator();
        while (iterator.hasNext() && placed < settings.buildBlocksPerCycle) {
            BuildBlock job = iterator.next();
            iterator.remove();
            Block block = world.getBlockAt(job.x, job.y, job.z);
            if (Settings.isArtificial(block.getType())) {
                continue;
            }
            if (settings.respectWorldGuard && protection.hasRegion(block.getLocation())) {
                continue;
            }
            placeData(block, job.data);
            placed++;
        }
        if (queue.isEmpty()) {
            Player player = Bukkit.getPlayer(state.playerId);
            state.task = TaskType.IDLE;
            soldiers.despawnAll(state.playerId);
            try {
                repository.saveArmy(state);
            } catch (SQLException ex) {
                plugin.getLogger().warning(ex.getMessage());
            }
            if (player != null) {
                Texts.send(player, "<green>The structure is finished.");
            }
        }
    }

    private static void placeData(Block block, String data) {
        try {
            if (data.contains("[")) {
                block.setBlockData(Bukkit.createBlockData(data), false);
            } else {
                Material material = Material.matchMaterial(data);
                if (material != null) {
                    block.setType(material, false);
                }
            }
        } catch (IllegalArgumentException ex) {
            Material material = Material.matchMaterial(data.split("\\[")[0]);
            if (material != null) {
                block.setType(material, false);
            }
        }
    }

    private boolean workSiteAllowed(Player player, Location location) {
        if (location.getWorld() == null) {
            return false;
        }
        if (settings.respectWorldGuard && protection.hasRegion(location) && !player.hasPermission("army.admin")) {
            Texts.send(player, "<red>Protected land cannot be mined or built on by the army.");
            return false;
        }
        if (settings.refusePlayerBuilds && Settings.artificialScore(location.getWorld(), location.getBlockX(), location.getBlockY(), location.getBlockZ()) > settings.maxArtificial
                && !player.hasPermission("army.admin")) {
            Texts.send(player, "<red>This looks like someone's base. Pick a wild spot.");
            return false;
        }
        return true;
    }

    private String attackProblem(Player player, Player target) {
        if (target == null) {
            return "<red>That player is not online.";
        }
        if (target.getUniqueId().equals(player.getUniqueId())) {
            return "<red>You cannot attack yourself.";
        }
        if (player.getWorld() != target.getWorld()) {
            return "<red>That player is in another world.";
        }
        if (player.getLocation().distanceSquared(target.getLocation()) > (long) settings.attackOrderDistance * settings.attackOrderDistance) {
            return "<red>That player is farther than " + settings.attackOrderDistance + " blocks.";
        }
        if (!canHurt(target, player.getUniqueId(), target.getLocation())) {
            return "<red>You cannot attack that player. Check trust, PvP, gamemode, and region rules.";
        }
        return null;
    }

    private Player nearestEnemy(Player player) {
        Player best = null;
        double bestDistance = (long) settings.attackOrderDistance * settings.attackOrderDistance;
        for (Player other : player.getWorld().getPlayers()) {
            if (attackProblem(player, other) != null) {
                continue;
            }
            double distance = other.getLocation().distanceSquared(player.getLocation());
            if (distance < bestDistance) {
                bestDistance = distance;
                best = other;
            }
        }
        return best;
    }

    private ArmyState requireArmy(Player player) {
        ArmyState state = state(player);
        if (state.soldiers <= 0) {
            Texts.send(player, "<red>You have no soldiers yet. Find a hidden castle and right-click its heart relic.");
            return null;
        }
        return state;
    }

    private boolean save(Player player, ArmyState state) {
        try {
            repository.saveArmy(state);
            return true;
        } catch (SQLException ex) {
            Texts.send(player, "<red>Could not save your army.");
            plugin.getLogger().warning(ex.getMessage());
            return false;
        }
    }

    private int assigned(ArmyState state) {
        String role = switch (state.task) {
            case DEFEND -> "defend";
            case ATTACK -> "attack";
            case MINE -> "mine";
            case BUILD -> "build";
            case FOLLOW, RETURN -> "follow";
            case IDLE -> "";
        };
        if (role.isEmpty()) {
            return 0;
        }
        return Math.min(state.soldiers, settings.assignedFor(role));
    }

    private int available(ArmyState state) {
        return Math.max(0, state.soldiers - assigned(state));
    }

    private int clampRadius(int radius) {
        return Math.max(settings.minRadius, Math.min(settings.maxRadius, radius));
    }

    private long expires() {
        return System.currentTimeMillis() + settings.selectionTimeoutSeconds * 1000L;
    }

    private void clearSelection(Player player) {
        selections.remove(player.getUniqueId());
    }

    private Location defenseLocation(ArmyState state) {
        if (state.defenseWorld == null) {
            return null;
        }
        World world = Bukkit.getWorld(state.defenseWorld);
        if (world == null) {
            return null;
        }
        return new Location(world, state.defenseX, state.defenseY, state.defenseZ);
    }

    private static void give(Player player, ItemStack stack) {
        var leftover = player.getInventory().addItem(stack);
        leftover.values().forEach(item -> player.getWorld().dropItemNaturally(player.getLocation(), item));
    }

    private static String discoveredNames(ArmyState state) {
        if (state.discovered.isEmpty()) {
            return "none";
        }
        List<String> names = new ArrayList<>();
        for (Realm realm : Realm.values()) {
            if (state.discovered.contains(realm.id)) {
                names.add(realm.display);
            }
        }
        return String.join(", ", names);
    }

    private record Selection(String mode, String template, long expires) {
    }

    private record PendingAttack(UUID target, long expires) {
    }

    private record BuildBlock(int x, int y, int z, String data) {
    }
}
