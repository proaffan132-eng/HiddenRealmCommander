package net.nexora.army.model;

public record CastleRecord(Realm realm, String world, int x, int y, int z) {
}
