package net.nexora.army.model;

import java.util.Locale;
import java.util.Optional;

public enum Realm {
    OVERWORLD("overworld", "Ancient Kingdom", "the Overworld", "NORMAL", "lodestone"),
    NETHER("nether", "Infernal Fortress", "the Nether", "NETHER", "respawn_anchor"),
    END("end", "Celestial Citadel", "the End", "THE_END", "dragon_egg");

    public final String id;
    public final String display;
    public final String realmName;
    public final String environment;
    public final String relic;

    Realm(String id, String display, String realmName, String environment, String relic) {
        this.id = id;
        this.display = display;
        this.realmName = realmName;
        this.environment = environment;
        this.relic = relic;
    }

    public static Optional<Realm> byId(String raw) {
        if (raw == null) {
            return Optional.empty();
        }
        String id = raw.toLowerCase(Locale.ROOT);
        for (Realm realm : values()) {
            if (realm.id.equals(id) || realm.environment.equalsIgnoreCase(raw) || realm.display.equalsIgnoreCase(raw)) {
                return Optional.of(realm);
            }
        }
        return Optional.empty();
    }
}
