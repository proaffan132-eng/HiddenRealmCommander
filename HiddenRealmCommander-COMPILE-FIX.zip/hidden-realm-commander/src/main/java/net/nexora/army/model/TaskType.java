package net.nexora.army.model;

public enum TaskType {
    IDLE,
    FOLLOW,
    DEFEND,
    ATTACK,
    MINE,
    BUILD,
    RETURN;

    public static TaskType parse(String raw) {
        if (raw == null || raw.isBlank()) {
            return IDLE;
        }
        try {
            return valueOf(raw.trim().toUpperCase());
        } catch (IllegalArgumentException ex) {
            return IDLE;
        }
    }

    public String label() {
        return switch (this) {
            case IDLE -> "Standing by";
            case FOLLOW -> "Following";
            case DEFEND -> "Defending";
            case ATTACK -> "Attacking";
            case MINE -> "Mining";
            case BUILD -> "Building";
            case RETURN -> "Returning";
        };
    }
}
