package net.nexora.army;

import net.nexora.army.army.ArmyService;
import net.nexora.army.army.ArmyMenus;
import net.nexora.army.army.ProtectionHook;
import net.nexora.army.army.SoldierManager;
import net.nexora.army.castle.CastleService;
import net.nexora.army.config.Settings;
import net.nexora.army.db.Database;
import net.nexora.army.db.Repository;
import net.nexora.army.model.CastleRecord;
import net.nexora.army.model.Realm;
import net.nexora.army.util.Keys;
import net.nexora.army.util.Texts;
import org.bukkit.Bukkit;
import org.bukkit.World;
import org.bukkit.NamespacedKey;
import org.bukkit.Sound;
import org.bukkit.inventory.ItemStack;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.event.block.Action;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitTask;

import java.io.File;
import java.sql.SQLException;
import java.util.Locale;

public final class ArmyPlugin extends JavaPlugin implements Listener {
    private Database database;
    private Repository repository;
    private ArmyService army;
    private CastleService castles;
    private SoldierManager soldiers;
    private Settings settings;
    private BukkitTask ticker;

    @Override public void onEnable() {
        try {
            settings = Settings.load(this);
            database = new Database(new File(getDataFolder(), "hiddenrealm.db"));
            repository = new Repository(database);
            repository.load();
            Keys keys = new Keys(this);
            ProtectionHook protection = new ProtectionHook(this);
            soldiers = new SoldierManager(this, settings, keys);
            soldiers.removeLoadedOrphans();
            army = new ArmyService(this, settings, repository, soldiers, protection);
            castles = new CastleService(this, settings, repository, protection);
            Bukkit.getPluginManager().registerEvents(this, this);
            Bukkit.getPluginManager().registerEvents(new ArmyMenus(this, army), this);
            ticker = Bukkit.getScheduler().runTaskTimer(this, army::tick, 1L, 2L);
            for (Player player : Bukkit.getOnlinePlayers()) army.onJoin(player);
            getLogger().info("HiddenRealmCommander enabled. Stored castles: " + repository.castles().size());
        } catch (Exception ex) {
            getLogger().severe("Could not enable HiddenRealmCommander: " + ex.getMessage());
            ex.printStackTrace();
            Bukkit.getPluginManager().disablePlugin(this);
        }
    }

    @Override public void onDisable() {
        if (ticker != null) ticker.cancel();
        if (castles != null) castles.shutdown();
        if (soldiers != null && repository != null) {
            for (var state : repository.armies()) soldiers.despawnAll(state.playerId);
        }
        if (database != null) try { database.close(); } catch (SQLException ex) { getLogger().warning("Database close failed: " + ex.getMessage()); }
    }

    @Override public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        String name = command.getName().toLowerCase(Locale.ROOT);
        if (name.equals("start")) {
            if (!sender.hasPermission("army.admin")) { Texts.send(sender, "<red>You do not have permission."); return true; }
            castles.start(sender); return true;
        }
        if (name.equals("finder")) {
            if (!sender.hasPermission("army.admin")) { Texts.send(sender, "<red>You do not have permission."); return true; }
            if (args.length == 2 && args[0].equalsIgnoreCase("tp") && sender instanceof Player player) {
                Realm realm = Realm.byId(args[1]).orElse(null);
                if (realm == null) { Texts.send(sender, "<red>Usage: /finder tp <overworld|nether|end>"); return true; }
                CastleRecord record = repository.castle(realm.id).orElse(null);
                if (record == null) { Texts.send(sender, "<red>That castle has not been generated."); return true; }
                World world = Bukkit.getWorld(record.world());
                if (world == null) { Texts.send(sender, "<red>The castle world is not loaded."); return true; }
                player.teleport(world.getHighestBlockAt(record.x(), record.z()).getLocation().add(0.5, 1, 0.5));
                Texts.send(player, "<green>Teleported to " + realm.display + "."); return true;
            }
            if (repository.castles().isEmpty()) { Texts.send(sender, "<yellow>No castles have been generated yet."); return true; }
            for (CastleRecord r : repository.castles()) Texts.send(sender, "<gold>" + r.realm().display + " <gray>" + r.world() + " <white>" + r.x() + " " + r.y() + " " + r.z());
            if (sender instanceof Player) Texts.send(sender, "<gray>Use /finder tp <overworld|nether|end> to teleport.");
            return true;
        }
        if (name.equals("army")) {
            if (!(sender instanceof Player player)) { Texts.send(sender, "<red>Players only."); return true; }
            if (!player.hasPermission("army.use")) { Texts.send(player, "<red>You do not have permission."); return true; }
            if (args.length == 0) { army.open(player); return true; }
            String sub = args[0].toLowerCase(Locale.ROOT);
            switch (sub) {
                case "follow" -> army.follow(player);
                case "defend" -> {
                    if (args.length == 1) army.defendHere(player);
                    else if (args[1].equalsIgnoreCase("set")) army.beginDefendSelect(player);
                    else if (args[1].equalsIgnoreCase("stop")) army.stopDefense(player);
                    else if (args[1].equalsIgnoreCase("radius") && args.length >= 3) try { army.setRadius(player, Integer.parseInt(args[2])); } catch (NumberFormatException e) { Texts.send(player, "<red>Radius must be a number."); }
                    else army.help(player);
                }
                case "attack" -> {
                    if (args.length < 2) army.attackNearest(player);
                    else { Player target = Bukkit.getPlayerExact(args[1]); if (target == null) Texts.send(player, "<red>That player is not online."); else army.attack(player, target); }
                }
                case "mine" -> army.mine(player);
                case "build" -> { if (args.length == 1) army.openBuild(player); else army.beginBuild(player, args[1]); }
                case "return" -> army.returnArmy(player);
                case "dismiss" -> army.dismiss(player);
                case "stats" -> army.stats(player);
                case "help" -> army.help(player);
                case "trust", "untrust" -> {
                    if (args.length < 2) { Texts.send(player, "<yellow>Usage: /army " + sub + " <player>"); break; }
                    Player target = Bukkit.getPlayerExact(args[1]); if (target == null) Texts.send(player, "<red>That player is not online."); else army.trust(player, target, sub.equals("trust"));
                }
                default -> army.help(player);
            }
            return true;
        }
        return false;
    }

    @EventHandler public void onJoin(PlayerJoinEvent event) { army.onJoin(event.getPlayer()); castles.sendHints(event.getPlayer()); }
    @EventHandler public void onQuit(PlayerQuitEvent event) { army.onQuit(event.getPlayer()); }
    @EventHandler public void onInteract(PlayerInteractEvent event) {
        if (event.getHand() != EquipmentSlot.HAND) return;
        Player player = event.getPlayer();
        ItemStack held = event.getItem();
        if (held != null && held.hasItemMeta()) {
            String relicId = held.getItemMeta().getPersistentDataContainer().get(new NamespacedKey(this, "heart_relic"), PersistentDataType.STRING);
            if (relicId != null && (event.getAction() == Action.RIGHT_CLICK_AIR || event.getAction() == Action.RIGHT_CLICK_BLOCK)) {
                event.setCancelled(true);
                Realm realm = Realm.byId(relicId).orElse(null);
                if (realm == null) return;
                try {
                    boolean claimed = repository.claim(player.getUniqueId(), realm, settings.rewardPerCastle);
                    if (!claimed) {
                        Texts.send(player, "<yellow>You have already claimed the " + realm.display + " reward.");
                    } else {
                        if (held.getAmount() <= 1) player.getInventory().setItemInMainHand(null);
                        else held.setAmount(held.getAmount() - 1);
                        Texts.send(player, "<green>You discovered " + realm.display + "! <white>+" + settings.rewardPerCastle + " soldiers</white> added to your army.");
                        Texts.title(player, settings.discoveryTitle, settings.discoverySubtitle);
                        try { player.playSound(player.getLocation(), Sound.valueOf(settings.discoverySound.toUpperCase(java.util.Locale.ROOT)), 1f, 1f); } catch (IllegalArgumentException ignored) { }
                    }
                } catch (SQLException ex) {
                    getLogger().warning("Could not record relic claim: " + ex.getMessage());
                    Texts.send(player, "<red>Your relic could not be claimed. Please contact staff.");
                }
                return;
            }
        }
        if (event.getAction() == Action.RIGHT_CLICK_BLOCK && event.getClickedBlock() != null && army.handleSelection(player, event.getClickedBlock())) event.setCancelled(true);
    }
}
