package net.nexora.army.castle;

import net.nexora.army.army.ProtectionHook;
import net.nexora.army.config.Settings;
import net.nexora.army.db.Repository;
import net.nexora.army.model.CastleRecord;
import net.nexora.army.model.Pos;
import net.nexora.army.model.Realm;
import net.nexora.army.util.HintGenerator;
import net.nexora.army.util.SiteRules;
import net.nexora.army.util.Texts;
import org.bukkit.Bukkit;
import org.bukkit.HeightMap;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.block.Container;
import org.bukkit.block.Sign;
import org.bukkit.block.data.BlockData;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.NamespacedKey;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitTask;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.EnumSet;
import java.util.Iterator;
import java.util.List;
import java.util.Random;
import java.util.Set;

public final class CastleService {
    private final JavaPlugin plugin;
    private final Settings settings;
    private final Repository repository;
    private final ProtectionHook protection;
    private BukkitTask task;
    private boolean running;
    private Realm realm;
    private int attempt;
    private final List<Realm> pending = new ArrayList<>();
    private final Set<Realm> failed = EnumSet.noneOf(Realm.class);
    private Paste paste;
    private CommandSender initiator;

    public CastleService(JavaPlugin plugin, Settings settings, Repository repository, ProtectionHook protection) {
        this.plugin = plugin;
        this.settings = settings;
        this.repository = repository;
        this.protection = protection;
    }

    public boolean running() {
        return running;
    }

    public void shutdown() {
        if (task != null) {
            task.cancel();
        }
        if (paste != null) {
            paste.release();
        }
    }

    public void start(CommandSender sender) {
        if (running) {
            Texts.send(sender, "<yellow>Castle generation is already running.");
            return;
        }
        pending.clear();
        failed.clear();
        for (Realm realm : Realm.values()) {
            if (repository.castle(realm.id).isEmpty()) {
                pending.add(realm);
            }
        }
        initiator = sender;
        if (pending.isEmpty()) {
            Texts.send(sender, "<yellow>The three castles are already standing. They were not moved.");
            broadcastHints(sender);
            return;
        }
        running = true;
        realm = null;
        attempt = 0;
        Texts.send(sender, "<gray>Searching for hidden sites. This takes a short while and will not freeze the server.");
        task = Bukkit.getScheduler().runTaskTimer(plugin, this::tick, 1L, 1L);
    }

    private void tick() {
        try {
            if (paste != null) {
                paste.step();
                if (paste.done) {
                    paste.finish();
                    paste = null;
                }
                return;
            }
            if (realm == null) {
                if (pending.isEmpty()) {
                    finish();
                    return;
                }
                realm = pending.remove(0);
                attempt = 0;
                World world = world(realm);
                if (world == null) {
                    failed.add(realm);
                    Texts.send(initiator, "<red>No " + realm.realmName + " world is loaded, so that castle was skipped.");
                    realm = null;
                    return;
                }
                Texts.send(initiator, "<gray>Searching " + realm.realmName + " for the " + realm.display + "...");
            }
            World world = world(realm);
            if (world == null) {
                failed.add(realm);
                realm = null;
                return;
            }
            for (int i = 0; i < settings.attemptsPerTick && attempt < settings.searchAttempts; i++) {
                attempt++;
                Location site = trySite(realm, world, attempt);
                if (site != null) {
                    beginPaste(realm, site);
                    realm = null;
                    return;
                }
            }
            if (attempt >= settings.searchAttempts) {
                failed.add(realm);
                Texts.send(initiator, "<red>No safe site was found for the " + realm.display + ". Move players away from the wilds or relax the distances in config.yml, then run /start again.");
                realm = null;
            }
        } catch (RuntimeException ex) {
            plugin.getLogger().warning("Castle search failed: " + ex.getMessage());
            Texts.send(initiator, "<red>Castle generation hit an error. Check the server log.");
            finish();
        }
    }

    private void finish() {
        running = false;
        if (task != null) {
            task.cancel();
            task = null;
        }
        broadcastHints(initiator);
    }

    public void broadcastHints(CommandSender sender) {
        List<String> lines = new ArrayList<>();
        for (CastleRecord record : repository.castles()) {
            String hint = HintGenerator.coordinateHint(record.realm().display, record.realm().realmName, record.x(), record.z(), settings.hintRounding);
            lines.add(hint);
            try {
                repository.putMeta("hint." + record.realm().id, hint);
                repository.putMeta("started", "true");
            } catch (SQLException ex) {
                plugin.getLogger().warning("Could not store a hint: " + ex.getMessage());
            }
        }
        if (lines.isEmpty()) {
            Texts.send(sender, "<red>No castles are recorded.");
            return;
        }
        if (!settings.broadcastHints) {
            Texts.send(sender, "<green>Castles are ready. Public hints are disabled in config.yml.");
            return;
        }
        Bukkit.broadcast(Texts.prefixed("<gold>Hidden realms have opened."));
        Bukkit.broadcast(Texts.prefixed("<gray>Each castle you personally discover grants <white>" + settings.rewardPerCastle + "</white> soldiers. All three grant <white>" + (settings.rewardPerCastle * 3) + "</white>."));
        for (String line : lines) {
            Bukkit.broadcast(Texts.prefixed("<yellow>" + line));
        }
        Bukkit.broadcast(Texts.prefixed("<gray>Find the heart relic inside each castle and right-click it. Exact coordinates stay with the staff."));
        if (settings.startTitle) {
            for (Player player : Bukkit.getOnlinePlayers()) {
                Texts.title(player, "<gold>Hidden Realms", "<gray>Coordinate hints are in chat");
            }
        }
        if (!failed.isEmpty()) {
            Texts.send(sender, "<yellow>Some realms were not placed. Run /start again to fill only the missing castles.");
        } else if (repository.castles().size() >= 3) {
            Texts.send(sender, "<green>Three castles are marked. Use /finder for exact coordinates.");
        }
    }

    public void sendHints(Player player) {
        if (!settings.hintsOnJoin || !"true".equals(repository.meta("started"))) {
            return;
        }
        List<String> lines = repository.hintLines();
        if (lines.isEmpty()) {
            return;
        }
        Texts.send(player, "<gold>Hidden realms are open.");
        for (String line : lines) {
            Texts.send(player, "<yellow>" + line);
        }
    }

    private void beginPaste(Realm realm, Location site) {
        StructurePlan plan = CastleBlueprints.castle(realm);
        World world = site.getWorld();
        int ox = site.getBlockX();
        int oy = site.getBlockY();
        int oz = site.getBlockZ();
        List<BlockJob> jobs = new ArrayList<>();
        String foundation = switch (realm) {
            case NETHER -> "nether_bricks";
            case END -> "end_stone";
            case OVERWORLD -> "deepslate_bricks";
        };
        for (Pos column : plan.columnMins()) {
            if (((column.x() + column.z()) & 1) == 1) {
                continue;
            }
            int x = ox + column.x();
            int z = oz + column.z();
            for (int depth = 1; depth <= settings.foundationDepth; depth++) {
                int y = oy + column.y() - depth;
                if (y <= world.getMinHeight()) {
                    break;
                }
                Material type = world.getBlockAt(x, y, z).getType();
                if (type.isSolid()) {
                    break;
                }
                jobs.add(new BlockJob(x, y, z, foundation, false));
            }
        }
        int markerX = ox + plan.marker.x();
        int markerY = oy + plan.marker.y();
        int markerZ = oz + plan.marker.z();
        for (var entry : plan.blocks.entrySet()) {
            Pos pos = entry.getKey();
            String data = entry.getValue();
            if ("air".equals(data) && world.getBlockAt(ox + pos.x(), oy + pos.y(), oz + pos.z()).getType().isAir()) {
                continue;
            }
            boolean chest = data.startsWith("chest");
            jobs.add(new BlockJob(ox + pos.x(), oy + pos.y(), oz + pos.z(), data, chest));
        }
        paste = new Paste(realm, world, jobs, markerX, markerY, markerZ, plan);
        Texts.send(initiator, "<green>Placing the " + realm.display + " at a hidden site in " + world.getName() + ".");
    }

    private Location trySite(Realm realm, World world, int attempt) {
        long seed = world.getSeed() ^ (realm.id.hashCode() * 73428767L) ^ (attempt * 104729L);
        Random random = new Random(seed);
        int range = Math.max(128, settings.horizontalRange(realm));
        int x = random.nextInt(range * 2 + 1) - range;
        int z = random.nextInt(range * 2 + 1) - range;
        Location spawn = world.getSpawnLocation();
        if (!SiteRules.farEnough(x, z, spawn.getBlockX(), spawn.getBlockZ(), settings.minSpawn(realm))) {
            return null;
        }
        if (realm == Realm.END && !SiteRules.farEnough(x, z, 0, 0, settings.endMinCenter)) {
            return null;
        }
        for (Player player : world.getPlayers()) {
            if (!SiteRules.farEnough(x, z, player.getLocation().getBlockX(), player.getLocation().getBlockZ(), settings.minPlayerDistance)) {
                return null;
            }
        }
        ensureChunk(world, x, z);
        if (realm == Realm.NETHER) {
            return netherSite(world, x, z);
        }
        int half = realm == Realm.OVERWORLD ? 36 : 26;
        int min = Integer.MAX_VALUE;
        int max = Integer.MIN_VALUE;
        for (int dx = -half; dx <= half; dx += 8) {
            for (int dz = -half; dz <= half; dz += 8) {
                ensureChunk(world, x + dx, z + dz);
                int y = world.getHighestBlockYAt(x + dx, z + dz, HeightMap.MOTION_BLOCKING_NO_LEAVES);
                Material type = world.getBlockAt(x + dx, y, z + dz).getType();
                if (type == Material.WATER || type == Material.LAVA || type == Material.ICE || type == Material.PACKED_ICE) {
                    return null;
                }
                min = Math.min(min, y);
                max = Math.max(max, y);
            }
        }
        if (!SiteRules.heightVarianceOk(new int[]{min, max}, settings.maxVariance)) {
            return null;
        }
        if (realm == Realm.OVERWORLD && (max < settings.overworldMinY || max > settings.overworldMaxY)) {
            return null;
        }
        if (Settings.artificialScore(world, x, max, z) > settings.maxArtificial) {
            return null;
        }
        Location location = new Location(world, x, max, z);
        if (!settings.ignoreWorldGuard && protection.hasRegion(location)) {
            return null;
        }
        return location;
    }

    private Location netherSite(World world, int x, int z) {
        for (int y = settings.netherMaxY; y >= settings.netherMinY; y--) {
            Block floor = world.getBlockAt(x, y, z);
            if (!floor.getType().isSolid() || floor.getType() == Material.LAVA || floor.getType() == Material.MAGMA_BLOCK) {
                continue;
            }
            boolean open = true;
            for (int height = 1; height <= settings.netherHeadroom; height++) {
                Material above = world.getBlockAt(x, y + height, z).getType();
                if (above.isSolid() || above == Material.LAVA) {
                    open = false;
                    break;
                }
            }
            if (!open || lavaNear(world, x, y, z)) {
                continue;
            }
            int min = y;
            int max = y;
            boolean blocked = false;
            for (int dx = -16; dx <= 16 && !blocked; dx += 8) {
                for (int dz = -16; dz <= 16; dz += 8) {
                    int floorY = netherFloorNear(world, x + dx, z + dz, y);
                    if (floorY < 0) {
                        blocked = true;
                        break;
                    }
                    min = Math.min(min, floorY);
                    max = Math.max(max, floorY);
                }
            }
            if (blocked || !SiteRules.heightVarianceOk(new int[]{min, max}, settings.maxVariance)) {
                continue;
            }
            if (Settings.artificialScore(world, x, y, z) > settings.maxArtificial) {
                return null;
            }
            Location location = new Location(world, x, y, z);
            if (!settings.ignoreWorldGuard && protection.hasRegion(location)) {
                return null;
            }
            return location;
        }
        return null;
    }

    private int netherFloorNear(World world, int x, int z, int around) {
        for (int y = around + 6; y >= around - 6; y--) {
            Block block = world.getBlockAt(x, y, z);
            if (block.getType() == Material.LAVA) {
                return -1;
            }
            if (block.getType().isSolid() && block.getType() != Material.MAGMA_BLOCK && world.getBlockAt(x, y + 1, z).isPassable()) {
                return y;
            }
        }
        return -1;
    }

    private boolean lavaNear(World world, int x, int y, int z) {
        for (int dx = -2; dx <= 2; dx++) {
            for (int dz = -2; dz <= 2; dz++) {
                Material type = world.getBlockAt(x + dx, y + 1, z + dz).getType();
                if (type == Material.LAVA) {
                    return true;
                }
            }
        }
        return false;
    }

    public World world(Realm realm) {
        String forced = settings.forcedWorld(realm);
        if (forced != null && !forced.isBlank()) {
            return Bukkit.getWorld(forced);
        }
        for (World world : Bukkit.getWorlds()) {
            if (world.getEnvironment().name().equals(realm.environment)) {
                return world;
            }
        }
        return null;
    }

    private void ensureChunk(World world, int x, int z) {
        int chunkX = x >> 4;
        int chunkZ = z >> 4;
        if (!world.isChunkLoaded(chunkX, chunkZ)) {
            world.getChunkAt(chunkX, chunkZ);
        }
    }

    private final class Paste {
        private final Realm realm;
        private final World world;
        private final List<BlockJob> jobs;
        private final int markerX;
        private final int markerY;
        private final int markerZ;
        private final List<int[]> tickets = new ArrayList<>();
        private int cursor;
        private int lootCursor;
        private boolean done;

        Paste(Realm realm, World world, List<BlockJob> jobs, int markerX, int markerY, int markerZ, StructurePlan plan) {
            this.realm = realm;
            this.world = world;
            this.jobs = jobs;
            this.markerX = markerX;
            this.markerY = markerY;
            this.markerZ = markerZ;
            int x1 = (plan.minX) >> 4;
            int x2 = (plan.maxX) >> 4;
            int z1 = (plan.minZ) >> 4;
            int z2 = (plan.maxZ) >> 4;
            // tickets are in world chunk coords, computed from the first job's origin via marker offset is messy.
            // Ticket every chunk the jobs touch instead.
            Set<Long> seen = new java.util.HashSet<>();
            for (BlockJob job : jobs) {
                int cx = job.x >> 4;
                int cz = job.z >> 4;
                long key = (((long) cx) << 32) ^ (cz & 0xffffffffL);
                if (seen.add(key)) {
                    world.addPluginChunkTicket(cx, cz, plugin);
                    tickets.add(new int[]{cx, cz});
                }
            }
        }

        void step() {
            int budget = settings.blocksPerTick;
            while (budget-- > 0 && cursor < jobs.size()) {
                place(jobs.get(cursor++));
            }
            if (cursor >= jobs.size()) {
                done = true;
            }
        }

        void finish() {
            try {
                repository.saveCastle(new CastleRecord(realm, world.getName(), markerX, markerY, markerZ));
                Texts.send(initiator, "<green>" + realm.display + " is sealed. Its relic is hidden inside the structure.");
            } catch (SQLException ex) {
                plugin.getLogger().severe("Could not save " + realm.display + ": " + ex.getMessage());
                Texts.send(initiator, "<red>The structure was placed but its location could not be saved.");
            }
            release();
        }

        void release() {
            for (int[] ticket : tickets) {
                world.removePluginChunkTicket(ticket[0], ticket[1], plugin);
            }
            tickets.clear();
        }

        private void place(BlockJob job) {
            Block block = world.getBlockAt(job.x, job.y, job.z);
            if ("air".equals(job.data)) {
                if (!block.getType().isAir()) {
                    block.setType(Material.AIR, false);
                }
                return;
            }
            try {
                BlockData data = Bukkit.createBlockData(job.data.contains(":") || job.data.contains("[") ? job.data : job.data);
                if (!job.data.contains("[")) {
                    Material material = Material.matchMaterial(job.data);
                    if (material == null) {
                        return;
                    }
                    block.setType(material, false);
                } else {
                    block.setBlockData(data, false);
                }
            } catch (IllegalArgumentException ex) {
                Material material = Material.matchMaterial(job.data.split("\\[")[0]);
                if (material != null) {
                    block.setType(material, false);
                }
                return;
            }
            if (job.chest) {
                if (block.getState() instanceof Container container) {
                    List<ItemStack> loot = settings.loot.getOrDefault(realm, List.of());
                    if (!loot.isEmpty()) {
                        container.getInventory().addItem(loot.get(lootCursor % loot.size()).clone());
                        lootCursor++;
                    }
                    Material relicMaterial = Material.matchMaterial(realm.relic.toUpperCase(java.util.Locale.ROOT));
                    if (relicMaterial == null) relicMaterial = Material.NETHER_STAR;
                    ItemStack relic = new ItemStack(relicMaterial);
                    ItemMeta relicMeta = relic.getItemMeta();
                    relicMeta.displayName(Texts.parse("<gold>" + realm.display + " Heart Relic"));
                    relicMeta.lore(List.of(Texts.parse("<gray>Right-click while holding this relic to claim " + settings.rewardPerCastle + " soldiers.")));
                    relicMeta.getPersistentDataContainer().set(new NamespacedKey(plugin, "heart_relic"), PersistentDataType.STRING, realm.id);
                    relic.setItemMeta(relicMeta);
                    container.getInventory().addItem(relic);
                }
            } else if (job.data.contains("sign") && block.getState() instanceof Sign sign) {
                sign.line(0, Texts.parse("<gold>Heart Relic"));
                sign.line(1, Texts.parse("<gray>Right-click"));
                sign.update(false, false);
            }
        }
    }

    private record BlockJob(int x, int y, int z, String data, boolean chest) {
    }
}
