package net.nexora.army.util;

public final class HintGenerator {
    private HintGenerator() {
    }

    public static int roundTo(int value, int rounding) {
        int step = Math.max(1, rounding);
        int sign = value < 0 ? -1 : 1;
        int magnitude = Math.abs(value);
        int rounded = Math.round(magnitude / (float) step) * step;
        return sign * rounded;
    }

    public static String direction(int x, int z) {
        int ax = Math.abs(x);
        int az = Math.abs(z);
        if (ax < 200 && az < 200) {
            return "near the center";
        }
        String northSouth = az < 200 ? "" : (z < 0 ? "north" : "south");
        String eastWest = ax < 200 ? "" : (x > 0 ? "east" : "west");
        if (northSouth.isEmpty()) {
            return eastWest;
        }
        if (eastWest.isEmpty()) {
            return northSouth;
        }
        return northSouth + eastWest;
    }

    public static String coordinateHint(String display, String realmName, int x, int z, int rounding) {
        int step = Math.max(1, rounding);
        int hx = roundTo(x, step);
        int hz = roundTo(z, step);
        return display + " in " + realmName + ": search within " + step
                + " blocks of X " + hx + ", Z " + hz + " (" + direction(x, z) + ").";
    }
}
