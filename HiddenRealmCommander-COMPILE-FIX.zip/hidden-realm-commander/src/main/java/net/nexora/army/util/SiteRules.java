package net.nexora.army.util;

public final class SiteRules {
    private SiteRules() {
    }

    public static boolean farEnough(int x, int z, int otherX, int otherZ, int minDistance) {
        long dx = (long) x - otherX;
        long dz = (long) z - otherZ;
        long min = Math.max(0, minDistance);
        return dx * dx + dz * dz >= min * min;
    }

    public static boolean heightVarianceOk(int[] heights, int maxVariance) {
        if (heights == null || heights.length == 0) {
            return false;
        }
        int min = heights[0];
        int max = heights[0];
        for (int height : heights) {
            if (height < min) {
                min = height;
            }
            if (height > max) {
                max = height;
            }
        }
        return max - min <= Math.max(0, maxVariance) && max > -64 && min < 320;
    }

    public static boolean artificialScoreOk(int score, int maxAllowed) {
        return score <= maxAllowed;
    }
}
