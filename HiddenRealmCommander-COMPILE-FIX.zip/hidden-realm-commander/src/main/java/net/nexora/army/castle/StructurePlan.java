package net.nexora.army.castle;

import net.nexora.army.model.Pos;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public final class StructurePlan {
    public final String name;
    public final Map<Pos, String> blocks;
    public final Pos marker;
    public final String markerMaterial;
    public final List<Pos> chests;
    public final int minX;
    public final int maxX;
    public final int minY;
    public final int maxY;
    public final int minZ;
    public final int maxZ;

    private StructurePlan(String name, Map<Pos, String> blocks, Pos marker, String markerMaterial, List<Pos> chests) {
        this.name = name;
        this.blocks = blocks;
        this.marker = marker;
        this.markerMaterial = markerMaterial;
        this.chests = chests;
        int xa = Integer.MAX_VALUE;
        int xb = Integer.MIN_VALUE;
        int ya = Integer.MAX_VALUE;
        int yb = Integer.MIN_VALUE;
        int za = Integer.MAX_VALUE;
        int zb = Integer.MIN_VALUE;
        for (Pos pos : blocks.keySet()) {
            xa = Math.min(xa, pos.x());
            xb = Math.max(xb, pos.x());
            ya = Math.min(ya, pos.y());
            yb = Math.max(yb, pos.y());
            za = Math.min(za, pos.z());
            zb = Math.max(zb, pos.z());
        }
        this.minX = xa;
        this.maxX = xb;
        this.minY = ya;
        this.maxY = yb;
        this.minZ = za;
        this.maxZ = zb;
    }

    public static StructurePlan of(String name, Brush brush, Pos marker, String markerMaterial, List<Pos> chests) {
        return new StructurePlan(name, Map.copyOf(brush.blocks()), marker, markerMaterial, List.copyOf(chests));
    }

    public int nonAir() {
        int count = 0;
        for (String data : blocks.values()) {
            if (data != null && !data.equals("air") && !data.startsWith("air[")) {
                count++;
            }
        }
        return count;
    }

    public boolean contains(Pos pos) {
        return pos.x() >= minX && pos.x() <= maxX && pos.y() >= minY && pos.y() <= maxY && pos.z() >= minZ && pos.z() <= maxZ;
    }

    public List<Pos> columnMins() {
        List<Pos> columns = new ArrayList<>();
        boolean[] seen = null;
        int width = maxX - minX + 1;
        int depth = maxZ - minZ + 1;
        int[] lowest = new int[width * depth];
        java.util.Arrays.fill(lowest, Integer.MAX_VALUE);
        boolean[] present = new boolean[width * depth];
        for (var entry : blocks.entrySet()) {
            if ("air".equals(entry.getValue())) {
                continue;
            }
            Pos pos = entry.getKey();
            int index = (pos.x() - minX) * depth + (pos.z() - minZ);
            present[index] = true;
            if (pos.y() < lowest[index]) {
                lowest[index] = pos.y();
            }
        }
        for (int x = minX; x <= maxX; x++) {
            for (int z = minZ; z <= maxZ; z++) {
                int index = (x - minX) * depth + (z - minZ);
                if (present[index]) {
                    columns.add(new Pos(x, lowest[index], z));
                }
            }
        }
        return columns;
    }
}
