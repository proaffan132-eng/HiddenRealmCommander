package net.nexora.army.army;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.plugin.Plugin;

import java.lang.reflect.Method;

public final class ProtectionHook {
    private final Plugin plugin;
    private boolean warned;

    public ProtectionHook(Plugin plugin) {
        this.plugin = plugin;
    }

    public boolean hasRegion(Location location) {
        Object set = regions(location);
        if (set == null) {
            return false;
        }
        try {
            Object size = set.getClass().getMethod("size").invoke(set);
            return size instanceof Number number && number.intValue() > 0;
        } catch (ReflectiveOperationException ex) {
            warn(ex);
            return false;
        }
    }

    public boolean deniesPvp(Location location) {
        Object set = regions(location);
        if (set == null) {
            return false;
        }
        try {
            Class<?> flags = Class.forName("com.sk89q.worldguard.protection.flags.Flags");
            Object pvp = flags.getField("PVP").get(null);
            Class<?> localPlayer = Class.forName("com.sk89q.worldguard.LocalPlayer");
            Class<?> stateFlag = Class.forName("com.sk89q.worldguard.protection.flags.StateFlag");
            Method queryState = set.getClass().getMethod("queryState", localPlayer, stateFlag);
            Object state = queryState.invoke(set, null, pvp);
            return state != null && "DENY".equalsIgnoreCase(state.toString());
        } catch (ReflectiveOperationException ex) {
            warn(ex);
            return false;
        }
    }

    private Object regions(Location location) {
        Plugin worldGuard = Bukkit.getPluginManager().getPlugin("WorldGuard");
        if (worldGuard == null || !worldGuard.isEnabled()) {
            return null;
        }
        try {
            Class<?> wg = Class.forName("com.sk89q.worldguard.WorldGuard");
            Object instance = wg.getMethod("getInstance").invoke(null);
            Object platform = wg.getMethod("getPlatform").invoke(instance);
            Object container = platform.getClass().getMethod("getRegionContainer").invoke(platform);
            Object query = container.getClass().getMethod("createQuery").invoke(container);
            Class<?> adapter = Class.forName("com.sk89q.worldedit.bukkit.BukkitAdapter");
            Object adapted = adapter.getMethod("adapt", Location.class).invoke(null, location);
            for (Method method : query.getClass().getMethods()) {
                if (!method.getName().equals("getApplicableRegions") || method.getParameterCount() != 1) {
                    continue;
                }
                if (method.getParameterTypes()[0].isAssignableFrom(adapted.getClass())) {
                    return method.invoke(query, adapted);
                }
            }
            warn(new NoSuchMethodException("getApplicableRegions"));
            return null;
        } catch (ReflectiveOperationException ex) {
            warn(ex);
            return null;
        }
    }

    private void warn(Exception ex) {
        if (warned) {
            return;
        }
        warned = true;
        plugin.getLogger().warning("WorldGuard hook is unavailable: " + ex.getMessage());
    }
}
