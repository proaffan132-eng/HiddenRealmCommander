package net.nexora.army.db;

import java.io.File;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public final class Database implements AutoCloseable {
    private final Connection connection;

    public Database(File file) throws SQLException {
        File parent = file.getParentFile();
        if (parent != null) {
            parent.mkdirs();
        }
        connection = DriverManager.getConnection("jdbc:sqlite:" + file.getAbsolutePath());
        try (Statement statement = connection.createStatement()) {
            statement.execute("PRAGMA journal_mode=WAL");
            statement.execute("PRAGMA synchronous=NORMAL");
            statement.execute("PRAGMA foreign_keys=ON");
            statement.executeUpdate("""
                    CREATE TABLE IF NOT EXISTS castles (
                      id TEXT PRIMARY KEY,
                      world TEXT NOT NULL,
                      x INTEGER NOT NULL,
                      y INTEGER NOT NULL,
                      z INTEGER NOT NULL
                    )""");
            statement.executeUpdate("""
                    CREATE TABLE IF NOT EXISTS discoveries (
                      uuid TEXT NOT NULL,
                      castle TEXT NOT NULL,
                      found_at INTEGER NOT NULL,
                      PRIMARY KEY (uuid, castle)
                    )""");
            statement.executeUpdate("""
                    CREATE TABLE IF NOT EXISTS armies (
                      uuid TEXT PRIMARY KEY,
                      soldiers INTEGER NOT NULL,
                      task TEXT NOT NULL,
                      task_world TEXT,
                      task_x INTEGER,
                      task_y INTEGER,
                      task_z INTEGER,
                      task_target TEXT,
                      task_extra TEXT,
                      defense_active INTEGER NOT NULL,
                      defense_world TEXT,
                      defense_x INTEGER,
                      defense_y INTEGER,
                      defense_z INTEGER,
                      defense_radius INTEGER
                    )""");
            statement.executeUpdate("""
                    CREATE TABLE IF NOT EXISTS trusted (
                      owner TEXT NOT NULL,
                      trusted TEXT NOT NULL,
                      PRIMARY KEY (owner, trusted)
                    )""");
            statement.executeUpdate("""
                    CREATE TABLE IF NOT EXISTS meta (
                      k TEXT PRIMARY KEY,
                      v TEXT NOT NULL
                    )""");
        }
    }

    public Connection connection() {
        return connection;
    }

    @Override
    public void close() throws SQLException {
        connection.close();
    }
}
