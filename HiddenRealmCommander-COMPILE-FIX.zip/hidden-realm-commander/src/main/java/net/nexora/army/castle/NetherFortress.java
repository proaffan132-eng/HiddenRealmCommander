package net.nexora.army.castle;

import net.nexora.army.model.Pos;

import java.util.List;

/** Infernal Fortress: blackstone ramparts, crimson roofs, and a gilded sanctum. */
public final class NetherFortress {
    private NetherFortress() {
    }

    public static StructurePlan create() {
        Brush brush = new Brush();
        String wall = "polished_blackstone_bricks";
        String dark = "blackstone";
        String red = "red_nether_bricks";
        String slab = "polished_blackstone_brick_slab[type=bottom]";
        String stairs = "crimson_stairs";
        String cap = "crimson_planks";

        brush.fill(-32, -3, -32, 32, -1, 32, "nether_bricks");
        brush.fill(-28, 0, -28, 28, 0, 28, "polished_blackstone");
        for (int i = -28; i <= 28; i += 3) {
            brush.fill(-28, 0, i, 28, 0, i, "magma_block");
        }
        brush.air(-26, 1, -26, 26, 12, 26);

        brush.walls(-28, 0, -28, 28, 8, 28, wall);
        brush.walls(-27, 1, -27, 27, 7, 27, dark);
        brush.merlons(-28, 9, -28, 28, 28, red);
        for (int t = -24; t <= 24; t += 6) {
            brush.fill(t, 1, -28, t, 8, -28, "gilded_blackstone");
            brush.fill(t, 1, 28, t, 8, 28, "gilded_blackstone");
            brush.fill(-28, 1, t, -28, 8, t, "gilded_blackstone");
            brush.fill(28, 1, t, 28, 8, t, "gilded_blackstone");
        }

        brush.tower(-28, -28, 18, 4, wall, slab, stairs, cap, "red_banner[rotation=8]");
        brush.tower(28, -28, 18, 4, wall, slab, stairs, cap, "red_banner[rotation=0]");
        brush.tower(-28, 28, 18, 4, wall, slab, stairs, cap, "black_banner[rotation=8]");
        brush.tower(28, 28, 18, 4, wall, slab, stairs, cap, "black_banner[rotation=0]");

        brush.air(-3, 1, 27, 3, 5, 30);
        brush.hollow(-7, 0, 24, 7, 11, 34, wall);
        brush.air(-2, 1, 24, 2, 5, 34);
        brush.fill(-7, 0, 24, 7, 0, 34, "polished_blackstone");
        brush.fill(-2, 6, 28, 2, 8, 28, "nether_brick_fence[east=true,west=true]");
        brush.set(-6, 2, 30, "soul_lantern[hanging=false]");
        brush.set(6, 2, 30, "soul_lantern[hanging=false]");
        brush.fill(-1, 1, 33, 1, 1, 33, "lava_cauldron");

        brush.hollow(-12, 0, -12, 12, 13, 12, "nether_bricks");
        brush.air(-11, 1, -11, 11, 11, 11);
        brush.air(-2, 1, 12, 2, 4, 12);
        brush.fill(-12, 0, -12, 12, 0, 12, red);
        brush.fill(0, 1, -2, 0, 1, 10, "red_nether_bricks");
        for (int y = 11; y >= 8; y--) {
            brush.set(-4, y, -4, "chain[axis=y]");
            brush.set(4, y, -4, "chain[axis=y]");
            brush.set(-4, y, 4, "chain[axis=y]");
            brush.set(4, y, 4, "chain[axis=y]");
        }
        brush.set(-4, 7, -4, "soul_lantern[hanging=true]");
        brush.set(4, 7, -4, "soul_lantern[hanging=true]");
        brush.set(-4, 7, 4, "soul_lantern[hanging=true]");
        brush.set(4, 7, 4, "soul_lantern[hanging=true]");
        brush.hollow(-5, 1, -8, 5, 5, -2, "gilded_blackstone");
        brush.air(-4, 2, -7, 4, 4, -3);
        brush.air(0, 2, -2, 0, 3, -2);
        brush.set(0, 2, -5, "respawn_anchor");
        brush.fill(-1, 1, -6, 1, 1, -4, "gold_block");
        brush.set(0, 3, -7, "crimson_wall_sign[facing=south]");
        brush.squareRoof(0, 0, 14, 7, stairs, cap);

        for (int step = 0; step <= 6; step++) {
            brush.air(9, -step, 4 + step, 11, 1 - step, 6 + step);
            brush.set(10, -step, 4 + step, "nether_brick_stairs[facing=south,half=bottom,shape=straight]");
        }
        brush.hollow(-8, -7, -16, 8, -3, -8, "polished_blackstone_bricks");
        brush.air(-7, -6, -15, 7, -4, -9);
        brush.fill(-8, -7, -16, 8, -7, -8, "gilded_blackstone");
        Pos chestA = new Pos(-5, -6, -14);
        Pos chestB = new Pos(5, -6, -14);
        Pos chestC = new Pos(0, -6, -10);
        brush.set(chestA.x(), chestA.y(), chestA.z(), "chest[facing=south,type=single]");
        brush.set(chestB.x(), chestB.y(), chestB.z(), "chest[facing=south,type=single]");
        brush.set(chestC.x(), chestC.y(), chestC.z(), "chest[facing=north,type=single]");
        brush.fill(-2, -6, -13, 2, -6, -12, "gold_block");

        brush.fill(-30, 1, 6, -28, 2, 7, "crimson_roots");
        brush.air(-27, 1, 6, -25, 2, 7);
        brush.set(0, 1, 0, "lava_cauldron");
        brush.fill(-14, 1, -20, -12, 2, -18, "crying_obsidian");
        brush.fill(12, 1, -20, 14, 2, -18, "crying_obsidian");

        return StructurePlan.of("Infernal Fortress", brush, new Pos(0, 2, -5), "respawn_anchor",
                List.of(chestA, chestB, chestC));
    }
}
