package net.nexora.army.castle;

import net.nexora.army.model.Pos;

import java.util.LinkedHashMap;
import java.util.Map;

public final class Brush {
    private final Map<Pos, String> blocks = new LinkedHashMap<>();

    public void set(int x, int y, int z, String data) {
        blocks.put(new Pos(x, y, z), data);
    }

    public void fill(int x1, int y1, int z1, int x2, int y2, int z2, String data) {
        int xa = Math.min(x1, x2);
        int xb = Math.max(x1, x2);
        int ya = Math.min(y1, y2);
        int yb = Math.max(y1, y2);
        int za = Math.min(z1, z2);
        int zb = Math.max(z1, z2);
        for (int x = xa; x <= xb; x++) {
            for (int y = ya; y <= yb; y++) {
                for (int z = za; z <= zb; z++) {
                    set(x, y, z, data);
                }
            }
        }
    }

    public void air(int x1, int y1, int z1, int x2, int y2, int z2) {
        fill(x1, y1, z1, x2, y2, z2, "air");
    }

    public void walls(int x1, int y1, int z1, int x2, int y2, int z2, String data) {
        int xa = Math.min(x1, x2);
        int xb = Math.max(x1, x2);
        int ya = Math.min(y1, y2);
        int yb = Math.max(y1, y2);
        int za = Math.min(z1, z2);
        int zb = Math.max(z1, z2);
        for (int y = ya; y <= yb; y++) {
            for (int x = xa; x <= xb; x++) {
                for (int z = za; z <= zb; z++) {
                    if (x == xa || x == xb || z == za || z == zb) {
                        set(x, y, z, data);
                    }
                }
            }
        }
    }

    public void hollow(int x1, int y1, int z1, int x2, int y2, int z2, String data) {
        int xa = Math.min(x1, x2);
        int xb = Math.max(x1, x2);
        int ya = Math.min(y1, y2);
        int yb = Math.max(y1, y2);
        int za = Math.min(z1, z2);
        int zb = Math.max(z1, z2);
        for (int y = ya; y <= yb; y++) {
            for (int x = xa; x <= xb; x++) {
                for (int z = za; z <= zb; z++) {
                    if (x == xa || x == xb || y == ya || y == yb || z == za || z == zb) {
                        set(x, y, z, data);
                    }
                }
            }
        }
    }

    public void merlons(int x1, int y, int z1, int x2, int z2, String data) {
        int xa = Math.min(x1, x2);
        int xb = Math.max(x1, x2);
        int za = Math.min(z1, z2);
        int zb = Math.max(z1, z2);
        for (int x = xa; x <= xb; x++) {
            if (((x + za) & 1) == 0) {
                set(x, y, za, data);
                set(x, y, zb, data);
            }
        }
        for (int z = za; z <= zb; z++) {
            if (((z + xa) & 1) == 0) {
                set(xa, y, z, data);
                set(xb, y, z, data);
            }
        }
    }

    public void squareRoof(int cx, int cz, int baseY, int radius, String stairs, String fill) {
        for (int layer = 0; layer <= radius; layer++) {
            int r = radius - layer;
            int y = baseY + layer;
            for (int x = cx - r; x <= cx + r; x++) {
                for (int z = cz - r; z <= cz + r; z++) {
                    boolean edge = x == cx - r || x == cx + r || z == cz - r || z == cz + r;
                    if (r == 0 || !edge) {
                        set(x, y, z, fill);
                    } else {
                        set(x, y, z, stairs + "[facing=" + facingOut(x, z, cx, cz) + ",half=bottom,shape=straight]");
                    }
                }
            }
        }
    }

    public void tower(int cx, int cz, int height, int radius, String wall, String slab, String stairs, String cap, String banner) {
        walls(cx - radius, 0, cz - radius, cx + radius, height, cz + radius, wall);
        fill(cx - radius, 0, cz - radius, cx + radius, 0, cz + radius, wall);
        if (radius > 1) {
            air(cx - radius + 1, 1, cz - radius + 1, cx + radius - 1, height - 1, cz + radius - 1);
            int floorY = Math.max(4, height / 2);
            fill(cx - radius + 1, floorY, cz - radius + 1, cx + radius - 1, floorY, cz + radius - 1, slab);
            for (int y = 1; y < height; y++) {
                set(cx + radius - 1, y, cz, "ladder[facing=west]");
            }
        }
        set(cx, 5, cz - radius, "glass_pane[east=true,west=true]");
        set(cx, 6, cz - radius, "glass_pane[east=true,west=true]");
        set(cx, 5, cz + radius, "glass_pane[east=true,west=true]");
        set(cx, 6, cz + radius, "glass_pane[east=true,west=true]");
        set(cx - radius, 5, cz, "glass_pane[north=true,south=true]");
        set(cx - radius, 6, cz, "glass_pane[north=true,south=true]");
        set(cx + radius, 5, cz, "glass_pane[north=true,south=true]");
        set(cx + radius, 6, cz, "glass_pane[north=true,south=true]");
        squareRoof(cx, cz, height + 1, radius, stairs, cap);
        set(cx, height + 1 + radius + 1, cz, banner);
    }

    public Map<Pos, String> blocks() {
        return blocks;
    }

    public int nonAir() {
        int count = 0;
        for (String data : blocks.values()) {
            if (!"air".equals(data)) {
                count++;
            }
        }
        return count;
    }

    private static String facingOut(int x, int z, int cx, int cz) {
        int dx = x - cx;
        int dz = z - cz;
        if (Math.abs(dx) >= Math.abs(dz)) {
            return dx >= 0 ? "east" : "west";
        }
        return dz >= 0 ? "south" : "north";
    }
}
