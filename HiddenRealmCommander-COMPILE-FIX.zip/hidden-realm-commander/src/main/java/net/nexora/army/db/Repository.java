package net.nexora.army.db;

import net.nexora.army.model.ArmyState;
import net.nexora.army.model.CastleRecord;
import net.nexora.army.model.Realm;
import net.nexora.army.model.TaskType;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;

public final class Repository {
    private final Database database;
    private final Map<String, CastleRecord> castles = new LinkedHashMap<>();
    private final Map<UUID, ArmyState> armies = new LinkedHashMap<>();
    private final Map<String, String> meta = new LinkedHashMap<>();

    public Repository(Database database) {
        this.database = database;
    }

    public synchronized void load() throws SQLException {
        castles.clear();
        armies.clear();
        meta.clear();
        Connection connection = database.connection();
        try (PreparedStatement statement = connection.prepareStatement("SELECT id, world, x, y, z FROM castles");
             ResultSet rows = statement.executeQuery()) {
            while (rows.next()) {
                Realm realm = Realm.byId(rows.getString(1)).orElse(null);
                if (realm == null) {
                    continue;
                }
                castles.put(realm.id, new CastleRecord(realm, rows.getString(2), rows.getInt(3), rows.getInt(4), rows.getInt(5)));
            }
        }
        try (PreparedStatement statement = connection.prepareStatement("""
                SELECT uuid, soldiers, task, task_world, task_x, task_y, task_z, task_target, task_extra,
                       defense_active, defense_world, defense_x, defense_y, defense_z, defense_radius
                FROM armies""");
             ResultSet rows = statement.executeQuery()) {
            while (rows.next()) {
                ArmyState state = new ArmyState(UUID.fromString(rows.getString(1)));
                state.soldiers = rows.getInt(2);
                state.task = TaskType.parse(rows.getString(3));
                state.taskWorld = rows.getString(4);
                state.taskX = rows.getInt(5);
                state.taskY = rows.getInt(6);
                state.taskZ = rows.getInt(7);
                state.taskTarget = rows.getString(8);
                state.taskExtra = rows.getString(9);
                state.defenseActive = rows.getInt(10) == 1;
                state.defenseWorld = rows.getString(11);
                state.defenseX = rows.getInt(12);
                state.defenseY = rows.getInt(13);
                state.defenseZ = rows.getInt(14);
                state.defenseRadius = rows.getInt(15);
                armies.put(state.playerId, state);
            }
        }
        try (PreparedStatement statement = connection.prepareStatement("SELECT uuid, castle FROM discoveries");
             ResultSet rows = statement.executeQuery()) {
            while (rows.next()) {
                ArmyState state = armies.computeIfAbsent(UUID.fromString(rows.getString(1)), ArmyState::new);
                state.discovered.add(rows.getString(2));
            }
        }
        try (PreparedStatement statement = connection.prepareStatement("SELECT owner, trusted FROM trusted");
             ResultSet rows = statement.executeQuery()) {
            while (rows.next()) {
                ArmyState state = armies.computeIfAbsent(UUID.fromString(rows.getString(1)), ArmyState::new);
                state.trusted.add(UUID.fromString(rows.getString(2)));
            }
        }
        try (PreparedStatement statement = connection.prepareStatement("SELECT k, v FROM meta");
             ResultSet rows = statement.executeQuery()) {
            while (rows.next()) {
                meta.put(rows.getString(1), rows.getString(2));
            }
        }
    }

    public synchronized Collection<CastleRecord> castles() {
        return List.copyOf(castles.values());
    }

    public synchronized Optional<CastleRecord> castle(String id) {
        return Optional.ofNullable(castles.get(id));
    }

    public synchronized Optional<CastleRecord> castleAt(String world, int x, int y, int z) {
        for (CastleRecord record : castles.values()) {
            if (record.world().equals(world) && record.x() == x && record.y() == y && record.z() == z) {
                return Optional.of(record);
            }
        }
        return Optional.empty();
    }

    public synchronized void saveCastle(CastleRecord record) throws SQLException {
        try (PreparedStatement statement = database.connection().prepareStatement(
                "INSERT INTO castles(id, world, x, y, z) VALUES(?, ?, ?, ?, ?) ON CONFLICT(id) DO UPDATE SET world=excluded.world, x=excluded.x, y=excluded.y, z=excluded.z")) {
            statement.setString(1, record.realm().id);
            statement.setString(2, record.world());
            statement.setInt(3, record.x());
            statement.setInt(4, record.y());
            statement.setInt(5, record.z());
            statement.executeUpdate();
        }
        castles.put(record.realm().id, record);
    }

    public synchronized ArmyState state(UUID playerId) {
        return armies.computeIfAbsent(playerId, ArmyState::new);
    }

    public synchronized Collection<ArmyState> armies() {
        return List.copyOf(armies.values());
    }

    /** @return true when this player had not already claimed the castle */
    public synchronized boolean claim(UUID playerId, Realm realm, int soldiers) throws SQLException {
        Connection connection = database.connection();
        boolean previous = connection.getAutoCommit();
        connection.setAutoCommit(false);
        try {
            try (PreparedStatement statement = connection.prepareStatement(
                    "INSERT OR IGNORE INTO discoveries(uuid, castle, found_at) VALUES(?, ?, ?)")) {
                statement.setString(1, playerId.toString());
                statement.setString(2, realm.id);
                statement.setLong(3, System.currentTimeMillis());
                if (statement.executeUpdate() == 0) {
                    connection.rollback();
                    return false;
                }
            }
            ArmyState state = state(playerId);
            int updated = state.soldiers + soldiers;
            writeArmy(state, updated);
            connection.commit();
            state.soldiers = updated;
            state.discovered.add(realm.id);
            return true;
        } catch (SQLException ex) {
            connection.rollback();
            throw ex;
        } finally {
            connection.setAutoCommit(previous);
        }
    }

    public synchronized void saveArmy(ArmyState state) throws SQLException {
        writeArmy(state, state.soldiers);
    }

    public synchronized void trust(UUID owner, UUID trusted, boolean add) throws SQLException {
        ArmyState state = state(owner);
        if (add) {
            try (PreparedStatement statement = database.connection().prepareStatement(
                    "INSERT OR IGNORE INTO trusted(owner, trusted) VALUES(?, ?)")) {
                statement.setString(1, owner.toString());
                statement.setString(2, trusted.toString());
                statement.executeUpdate();
            }
            state.trusted.add(trusted);
        } else {
            try (PreparedStatement statement = database.connection().prepareStatement(
                    "DELETE FROM trusted WHERE owner=? AND trusted=?")) {
                statement.setString(1, owner.toString());
                statement.setString(2, trusted.toString());
                statement.executeUpdate();
            }
            state.trusted.remove(trusted);
        }
    }

    public synchronized void putMeta(String key, String value) throws SQLException {
        try (PreparedStatement statement = database.connection().prepareStatement(
                "INSERT INTO meta(k, v) VALUES(?, ?) ON CONFLICT(k) DO UPDATE SET v=excluded.v")) {
            statement.setString(1, key);
            statement.setString(2, value);
            statement.executeUpdate();
        }
        meta.put(key, value);
    }

    public synchronized String meta(String key) {
        return meta.get(key);
    }

    public synchronized List<String> hintLines() {
        List<String> lines = new ArrayList<>();
        for (Realm realm : Realm.values()) {
            String line = meta.get("hint." + realm.id);
            if (line != null && !line.isBlank()) {
                lines.add(line);
            }
        }
        return lines;
    }

    private void writeArmy(ArmyState state, int soldiers) throws SQLException {
        try (PreparedStatement statement = database.connection().prepareStatement("""
                INSERT INTO armies(uuid, soldiers, task, task_world, task_x, task_y, task_z, task_target, task_extra,
                    defense_active, defense_world, defense_x, defense_y, defense_z, defense_radius)
                VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(uuid) DO UPDATE SET
                    soldiers=excluded.soldiers,
                    task=excluded.task,
                    task_world=excluded.task_world,
                    task_x=excluded.task_x,
                    task_y=excluded.task_y,
                    task_z=excluded.task_z,
                    task_target=excluded.task_target,
                    task_extra=excluded.task_extra,
                    defense_active=excluded.defense_active,
                    defense_world=excluded.defense_world,
                    defense_x=excluded.defense_x,
                    defense_y=excluded.defense_y,
                    defense_z=excluded.defense_z,
                    defense_radius=excluded.defense_radius
                """)) {
            statement.setString(1, state.playerId.toString());
            statement.setInt(2, soldiers);
            statement.setString(3, state.task.name());
            statement.setString(4, state.taskWorld);
            statement.setInt(5, state.taskX);
            statement.setInt(6, state.taskY);
            statement.setInt(7, state.taskZ);
            statement.setString(8, state.taskTarget);
            statement.setString(9, state.taskExtra);
            statement.setInt(10, state.defenseActive ? 1 : 0);
            statement.setString(11, state.defenseWorld);
            statement.setInt(12, state.defenseX);
            statement.setInt(13, state.defenseY);
            statement.setInt(14, state.defenseZ);
            statement.setInt(15, state.defenseRadius);
            statement.executeUpdate();
        }
    }
}
