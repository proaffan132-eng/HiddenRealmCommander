package net.nexora.army.army;

import net.nexora.army.config.Settings;
import net.nexora.army.util.Keys;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.attribute.Attribute;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Mob;
import org.bukkit.entity.Player;
import org.bukkit.entity.Zombie;
import org.bukkit.event.entity.CreatureSpawnEvent;
import org.bukkit.inventory.EntityEquipment;
import org.bukkit.inventory.ItemStack;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.Plugin;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public final class SoldierManager {
    private final Plugin plugin;
    private final Settings settings;
    private final Keys keys;
    private final Map<UUID, Soldier> soldiers = new ConcurrentHashMap<>();

    public SoldierManager(Plugin plugin, Settings settings, Keys keys) {
        this.plugin = plugin;
        this.settings = settings;
        this.keys = keys;
    }

    public int alive() {
        return soldiers.size();
    }

    public int alive(UUID owner) {
        int count = 0;
        for (Soldier soldier : soldiers.values()) {
            if (soldier.owner.equals(owner) && !soldier.entity.isDead()) {
                count++;
            }
        }
        return count;
    }

    public int aliveIn(World world) {
        int count = 0;
        for (Soldier soldier : soldiers.values()) {
            if (!soldier.entity.isDead() && world.equals(soldier.entity.getWorld())) {
                count++;
            }
        }
        return count;
    }

    public int aliveRole(UUID owner, String role) {
        int count = 0;
        for (Soldier soldier : soldiers.values()) {
            if (soldier.owner.equals(owner) && soldier.role.equals(role) && !soldier.entity.isDead()) {
                count++;
            }
        }
        return count;
    }

    public UUID ownerOf(Entity entity) {
        String raw = entity.getPersistentDataContainer().get(keys.owner, PersistentDataType.STRING);
        if (raw == null) {
            return null;
        }
        try {
            return UUID.fromString(raw);
        } catch (IllegalArgumentException ex) {
            return null;
        }
    }

    public String roleOf(Entity entity) {
        return entity.getPersistentDataContainer().get(keys.role, PersistentDataType.STRING);
    }

    public boolean isSoldier(Entity entity) {
        return entity.getPersistentDataContainer().has(keys.soldierId, PersistentDataType.STRING);
    }

    public Location leashOf(Entity entity) {
        Soldier soldier = soldier(entity);
        return soldier == null ? null : soldier.leash;
    }

    public void removeLoadedOrphans() {
        for (World world : Bukkit.getWorlds()) {
            for (Entity entity : world.getEntities()) {
                if (isSoldier(entity)) {
                    entity.remove();
                }
            }
        }
        soldiers.clear();
    }

    public void removeIfOrphan(Entity entity) {
        if (!isSoldier(entity)) {
            return;
        }
        if (soldier(entity) == null) {
            entity.remove();
        }
    }

    public void despawn(UUID owner, boolean keepGuards) {
        Iterator<Soldier> iterator = soldiers.values().iterator();
        while (iterator.hasNext()) {
            Soldier soldier = iterator.next();
            if (!soldier.owner.equals(owner)) {
                continue;
            }
            if (keepGuards && "defend".equals(soldier.role)) {
                continue;
            }
            if (!soldier.entity.isDead()) {
                soldier.entity.remove();
            }
            iterator.remove();
        }
    }

    public void despawnAll(UUID owner) {
        despawn(owner, false);
    }

    public int spawn(Player owner, String role, Location center, int wanted, int leashRadius) {
        if (center.getWorld() == null || wanted <= 0 || owner == null) {
            return 0;
        }
        int perPlayerCap = "defend".equals(role) ? settings.maxGuardsPerPlayer : settings.maxVisiblePerPlayer;
        int room = Math.min(wanted, perPlayerCap - alive(owner.getUniqueId()));
        room = Math.min(room, settings.maxActiveServer - alive());
        room = Math.min(room, settings.maxActivePerWorld - aliveIn(center.getWorld()));
        int spawned = 0;
        for (int i = 0; i < room; i++) {
            double angle = (Math.PI * 2 * i) / Math.max(1, room);
            Location spot = center.clone().add(Math.cos(angle) * 2.2, 0, Math.sin(angle) * 2.2);
            spot.setY(groundY(spot));
            Zombie zombie = spawnZombie(owner, role, spot);
            if (zombie == null) {
                break;
            }
            Soldier soldier = new Soldier(UUID.randomUUID(), owner.getUniqueId(), role, zombie, center.clone(), Math.max(4, leashRadius));
            zombie.getPersistentDataContainer().set(keys.owner, PersistentDataType.STRING, owner.getUniqueId().toString());
            zombie.getPersistentDataContainer().set(keys.soldierId, PersistentDataType.STRING, soldier.id.toString());
            zombie.getPersistentDataContainer().set(keys.role, PersistentDataType.STRING, role);
            soldiers.put(soldier.id, soldier);
            spawned++;
        }
        return spawned;
    }

    public void tick(TargetRules rules) {
        long now = System.currentTimeMillis();
        for (Soldier soldier : new ArrayList<>(soldiers.values())) {
            if (soldier.entity.isDead() || !soldier.entity.isValid() && soldier.entity.getWorld() == null) {
                soldiers.remove(soldier.id);
                continue;
            }
            if (!(soldier.entity instanceof Mob mob) || mob.isDead()) {
                soldiers.remove(soldier.id);
                continue;
            }
            Player owner = Bukkit.getPlayer(soldier.owner);
            switch (soldier.role) {
                case "follow" -> tickFollow(mob, owner, soldier);
                case "defend" -> tickDefend(mob, owner, soldier, rules, now);
                case "attack" -> tickAttack(mob, soldier, rules);
                case "return" -> tickReturn(mob, owner, soldier, now);
                default -> hold(mob, soldier);
            }
        }
    }

    private void tickFollow(Mob mob, Player owner, Soldier soldier) {
        mob.setTarget(null);
        if (owner == null || !owner.isOnline() || owner.getWorld() != mob.getWorld()) {
            return;
        }
        double distance = mob.getLocation().distance(owner.getLocation());
        if (distance > settings.followTeleportDistance) {
            mob.teleport(safeNear(owner.getLocation()));
            return;
        }
        if (distance > 3.2 && nowPath(soldier)) {
            mob.getPathfinder().moveTo(owner.getLocation(), settings.followSpeed);
        }
    }

    private void tickDefend(Mob mob, Player owner, Soldier soldier, TargetRules rules, long now) {
        Location home = soldier.leash;
        if (home.getWorld() == null || mob.getWorld() != home.getWorld()) {
            mob.teleport(safeNear(home));
            return;
        }
        if (home.distanceSquared(mob.getLocation()) > (long) soldier.leashRadius * soldier.leashRadius) {
            mob.setTarget(null);
            if (nowPath(soldier)) {
                mob.getPathfinder().moveTo(home, 1.15);
            }
            return;
        }
        Player intruder = rules.intruder(soldier.owner, home);
        if (intruder != null && rules.allowAttack(mob, intruder, home, soldier.leashRadius)) {
            mob.setTarget(intruder);
            if (nowPath(soldier)) {
                mob.getPathfinder().moveTo(intruder.getLocation(), 1.2);
            }
            return;
        }
        mob.setTarget(null);
        if (home.distanceSquared(mob.getLocation()) > 4) {
            Location point = patrol(home, soldier, now);
            if (nowPath(soldier)) {
                mob.getPathfinder().moveTo(point, 1.0);
            }
        }
    }

    private void tickAttack(Mob mob, Soldier soldier, TargetRules rules) {
        Player target = null;
        if (soldier.target != null) {
            target = Bukkit.getPlayer(soldier.target);
        }
        if (target == null || !target.isOnline() || !rules.allowAttack(mob, target, soldier.leash, soldier.leashRadius)) {
            mob.setTarget(null);
            hold(mob, soldier);
            return;
        }
        mob.setTarget(target);
        if (nowPath(soldier)) {
            mob.getPathfinder().moveTo(target.getLocation(), 1.25);
        }
    }

    private void tickReturn(Mob mob, Player owner, Soldier soldier, long now) {
        mob.setTarget(null);
        if (owner == null || !owner.isOnline() || now - soldier.since > 8000) {
            mob.remove();
            soldiers.remove(soldier.id);
            return;
        }
        if (mob.getWorld() != owner.getWorld() || mob.getLocation().distanceSquared(owner.getLocation()) < 9) {
            mob.remove();
            soldiers.remove(soldier.id);
            return;
        }
        if (nowPath(soldier)) {
            mob.getPathfinder().moveTo(owner.getLocation(), 1.3);
        }
    }

    private void hold(Mob mob, Soldier soldier) {
        mob.setTarget(null);
        if (soldier.leash.getWorld() != null && mob.getWorld() == soldier.leash.getWorld()
                && mob.getLocation().distanceSquared(soldier.leash) > 16 && nowPath(soldier)) {
            mob.getPathfinder().moveTo(soldier.leash, 1.0);
        }
    }

    public void setAttackTarget(UUID owner, UUID target) {
        for (Soldier soldier : soldiers.values()) {
            if (soldier.owner.equals(owner) && "attack".equals(soldier.role)) {
                soldier.target = target;
            }
        }
    }

    public void markReturning(UUID owner) {
        long now = System.currentTimeMillis();
        for (Soldier soldier : soldiers.values()) {
            if (soldier.owner.equals(owner)) {
                soldier.role = "return";
                soldier.since = now;
                soldier.entity.getPersistentDataContainer().set(keys.role, PersistentDataType.STRING, "return");
            }
        }
    }

    private boolean nowPath(Soldier soldier) {
        long time = System.currentTimeMillis();
        if (time - soldier.lastPath < 500) {
            return false;
        }
        soldier.lastPath = time;
        return true;
    }

    private Location patrol(Location home, Soldier soldier, long now) {
        if (now - soldier.since > 4000) {
            soldier.waypoint = (soldier.waypoint + 1) % 4;
            soldier.since = now;
        }
        double radius = 6;
        double angle = soldier.waypoint * (Math.PI / 2);
        return home.clone().add(Math.cos(angle) * radius, 0, Math.sin(angle) * radius);
    }

    private Zombie spawnZombie(Player owner, String role, Location spot) {
        try {
            return spot.getWorld().spawn(spot, Zombie.class, CreatureSpawnEvent.SpawnReason.CUSTOM, zombie -> prepare(zombie, owner, role));
        } catch (Throwable first) {
            try {
                Zombie zombie = spot.getWorld().spawn(spot, Zombie.class);
                prepare(zombie, owner, role);
                return zombie;
            } catch (Throwable second) {
                plugin.getLogger().warning("Could not spawn a soldier: " + second.getMessage());
                return null;
            }
        }
    }

    private void prepare(Zombie zombie, Player owner, String role) {
        zombie.setShouldBurnInDay(false);
        zombie.setRemoveWhenFarAway(false);
        zombie.setPersistent(true);
        zombie.setAdult();
        zombie.setCanPickupItems(false);
        zombie.setConversionTime(-1);
        zombie.customName(name(role, owner.getName()));
        zombie.setCustomNameVisible(true);
        attribute(zombie, "MAX_HEALTH", "GENERIC_MAX_HEALTH", settings.maxHealth);
        attribute(zombie, "MOVEMENT_SPEED", "GENERIC_MOVEMENT_SPEED", settings.movementSpeed);
        attribute(zombie, "ATTACK_DAMAGE", "GENERIC_ATTACK_DAMAGE", settings.attackDamage);
        attribute(zombie, "ATTACK_KNOCKBACK", "GENERIC_ATTACK_KNOCKBACK", settings.attackKnockback);
        attribute(zombie, "KNOCKBACK_RESISTANCE", "GENERIC_KNOCKBACK_RESISTANCE", settings.knockbackResistance);
        attribute(zombie, "FOLLOW_RANGE", "GENERIC_FOLLOW_RANGE", settings.followRange);
        if (zombie.getAttribute(resolve("MAX_HEALTH", "GENERIC_MAX_HEALTH")) != null) {
            zombie.setHealth(Math.min(zombie.getHealth(), settings.maxHealth));
        }
        EntityEquipment equipment = zombie.getEquipment();
        if (equipment != null) {
            equipment.setHelmet(new ItemStack(helmet(role)));
            equipment.setChestplate(new ItemStack(Material.IRON_CHESTPLATE));
            equipment.setLeggings(new ItemStack(Material.IRON_LEGGINGS));
            equipment.setBoots(new ItemStack(Material.IRON_BOOTS));
            equipment.setItemInMainHand(new ItemStack(tool(role)));
            equipment.setHelmetDropChance(0f);
            equipment.setChestplateDropChance(0f);
            equipment.setLeggingsDropChance(0f);
            equipment.setBootsDropChance(0f);
            equipment.setItemInMainHandDropChance(0f);
        }
    }

    private static Material helmet(String role) {
        return switch (role) {
            case "defend" -> Material.GOLDEN_HELMET;
            case "attack" -> Material.CHAINMAIL_HELMET;
            case "mine" -> Material.LEATHER_HELMET;
            case "build" -> Material.LEATHER_HELMET;
            default -> Material.IRON_HELMET;
        };
    }

    private static Material tool(String role) {
        return switch (role) {
            case "mine" -> Material.IRON_PICKAXE;
            case "build" -> Material.IRON_AXE;
            default -> Material.IRON_SWORD;
        };
    }

    private static Component name(String role, String owner) {
        NamedTextColor color = switch (role) {
            case "defend" -> NamedTextColor.GOLD;
            case "attack" -> NamedTextColor.RED;
            case "mine" -> NamedTextColor.AQUA;
            case "build" -> NamedTextColor.GREEN;
            default -> NamedTextColor.GRAY;
        };
        String word = switch (role) {
            case "defend" -> "Guard";
            case "attack" -> "Attacker";
            case "mine" -> "Miner";
            case "build" -> "Builder";
            default -> "Soldier";
        };
        return Component.text(word + " · " + owner, color);
    }

    private void attribute(LivingEntity entity, String modern, String legacy, double value) {
        Attribute attribute = resolve(modern, legacy);
        if (attribute == null) {
            return;
        }
        var instance = entity.getAttribute(attribute);
        if (instance != null) {
            instance.setBaseValue(value);
        }
    }

    private Attribute resolve(String modern, String legacy) {
        for (String name : List.of(modern, legacy)) {
            try {
                Field field = Attribute.class.getField(name);
                Object value = field.get(null);
                if (value instanceof Attribute attribute) {
                    return attribute;
                }
            } catch (ReflectiveOperationException ignored) {
                // try the next name
            }
        }
        return null;
    }

    private static double groundY(Location location) {
        World world = location.getWorld();
        int x = location.getBlockX();
        int z = location.getBlockZ();
        int y = location.getBlockY();
        for (int i = 0; i < 6; i++) {
            if (world.getBlockAt(x, y - 1, z).getType().isSolid() && world.getBlockAt(x, y, z).isPassable() && world.getBlockAt(x, y + 1, z).isPassable()) {
                return y;
            }
            y--;
        }
        return location.getY();
    }

    private static Location safeNear(Location location) {
        Location copy = location.clone().add(1.5, 0, 1.5);
        copy.setY(groundY(copy));
        return copy;
    }

    private Soldier soldier(Entity entity) {
        String raw = entity.getPersistentDataContainer().get(keys.soldierId, PersistentDataType.STRING);
        if (raw == null) {
            return null;
        }
        try {
            return soldiers.get(UUID.fromString(raw));
        } catch (IllegalArgumentException ex) {
            return null;
        }
    }

    public interface TargetRules {
        Player intruder(UUID owner, Location home);

        boolean allowAttack(Mob mob, Player target, Location leash, int leashDistance);
    }

    private static final class Soldier {
        final UUID id;
        final UUID owner;
        String role;
        final Entity entity;
        final Location leash;
        final int leashRadius;
        UUID target;
        int waypoint;
        long lastPath;
        long since = System.currentTimeMillis();

        Soldier(UUID id, UUID owner, String role, Entity entity, Location leash, int leashRadius) {
            this.id = id;
            this.owner = owner;
            this.role = role;
            this.entity = entity;
            this.leash = leash;
            this.leashRadius = leashRadius;
        }
    }
}
