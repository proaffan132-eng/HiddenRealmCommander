package net.nexora.army.util;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.MiniMessage;
import net.kyori.adventure.title.Title;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.time.Duration;

public final class Texts {
    private static final MiniMessage MINI = MiniMessage.miniMessage();
    public static final String PREFIX = "<dark_gray>[<gold>Realms</gold>]</dark_gray> ";

    private Texts() {
    }

    public static Component parse(String mini) {
        return MINI.deserialize(mini == null ? "" : mini);
    }

    public static Component prefixed(String mini) {
        return parse(PREFIX + mini);
    }

    public static void send(CommandSender sender, String mini) {
        sender.sendMessage(prefixed(mini));
    }

    public static void title(Player player, String title, String subtitle) {
        player.showTitle(Title.title(
                parse(title),
                parse(subtitle),
                Title.Times.times(Duration.ofMillis(400), Duration.ofMillis(2600), Duration.ofMillis(600))
        ));
    }
}
