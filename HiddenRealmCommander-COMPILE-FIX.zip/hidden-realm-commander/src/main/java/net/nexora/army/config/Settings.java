package net.nexora.army.config;

import net.nexora.army.model.Realm;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.util.ArrayList;
import java.util.EnumMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

public final class Settings {
    public final int hintRounding;
    public final boolean broadcastHints;
    public final boolean hintsOnJoin;
    public final boolean globalDiscovery;
    public final boolean startTitle;
    public final int searchAttempts;
    public final int attemptsPerTick;
    public final int minSpawnOverworld;
    public final int minSpawnNether;
    public final int minSpawnEnd;
    public final int minPlayerDistance;
    public final int maxArtificial;
    public final int maxVariance;
    public final boolean ignoreWorldGuard;
    public final int overworldMinY;
    public final int overworldMaxY;
    public final int netherMinY;
    public final int netherMaxY;
    public final int netherHeadroom;
    public final int endMinCenter;
    public final int rangeOverworld;
    public final int rangeNether;
    public final int rangeEnd;
    public final String worldOverworld;
    public final String worldNether;
    public final String worldEnd;
    public final int blocksPerTick;
    public final int foundationDepth;
    public final int rewardPerCastle;
    public final String discoveryTitle;
    public final String discoverySubtitle;
    public final String discoverySound;
    public final String discoveryParticle;
    public final int particleCount;
    public final Map<Realm, List<ItemStack>> loot;
    public final int maxVisiblePerPlayer;
    public final int maxGuardsPerPlayer;
    public final int maxActivePerWorld;
    public final int maxActiveServer;
    public final int visibleFollow;
    public final int visibleDefend;
    public final int visibleAttack;
    public final int visibleMine;
    public final int visibleBuild;
    public final int assignedFollow;
    public final int assignedDefend;
    public final int assignedAttack;
    public final int assignedMine;
    public final int assignedBuild;
    public final boolean resumeDefense;
    public final boolean resumeFollow;
    public final boolean keepGuardsOnQuit;
    public final int mineCycleSeconds;
    public final int mineMaxItems;
    public final boolean simulateMining;
    public final int realMineBlocks;
    public final int buildBlocksPerCycle;
    public final boolean refusePlayerBuilds;
    public final int selectionTimeoutSeconds;
    public final int followTeleportDistance;
    public final double followSpeed;
    public final int defaultRadius;
    public final int minRadius;
    public final int maxRadius;
    public final boolean defenseLeash;
    public final int attackOrderDistance;
    public final int attackLeash;
    public final double ironChance;
    public final double goldChance;
    public final Set<Material> realBreakable;
    public final double attackDamage;
    public final double attackKnockback;
    public final double knockbackResistance;
    public final double maxHealth;
    public final double movementSpeed;
    public final double followRange;
    public final boolean protectOwner;
    public final boolean protectTrusted;
    public final boolean respectWorldPvp;
    public final boolean respectWorldGuard;
    public final boolean ignoreCreative;
    public final long hitDelayMs;

    private Settings(FileConfiguration config, FileConfiguration castles, FileConfiguration army, FileConfiguration combat) {
        hintRounding = config.getInt("hint-rounding", 400);
        broadcastHints = config.getBoolean("broadcast-hints", true);
        hintsOnJoin = config.getBoolean("hints-on-join", true);
        globalDiscovery = config.getBoolean("global-discovery-announcement", true);
        startTitle = config.getBoolean("start-title", true);
        searchAttempts = config.getInt("search.attempts", 80);
        attemptsPerTick = Math.max(1, config.getInt("search.attempts-per-tick", 4));
        minSpawnOverworld = config.getInt("search.min-distance-from-spawn.overworld", 2500);
        minSpawnNether = config.getInt("search.min-distance-from-spawn.nether", 500);
        minSpawnEnd = config.getInt("search.min-distance-from-spawn.end", 700);
        minPlayerDistance = config.getInt("search.min-distance-from-player", 400);
        maxArtificial = config.getInt("search.max-artificial-blocks", 4);
        maxVariance = config.getInt("search.max-height-variance", 10);
        ignoreWorldGuard = config.getBoolean("search.ignore-worldguard", false);
        overworldMinY = config.getInt("search.overworld-min-y", 58);
        overworldMaxY = config.getInt("search.overworld-max-y", 150);
        netherMinY = config.getInt("search.nether-min-y", 32);
        netherMaxY = config.getInt("search.nether-max-y", 110);
        netherHeadroom = config.getInt("search.nether-headroom", 16);
        endMinCenter = config.getInt("search.end-min-distance-from-center", 1000);
        rangeOverworld = config.getInt("search.horizontal-range.overworld", 12000);
        rangeNether = config.getInt("search.horizontal-range.nether", 5000);
        rangeEnd = config.getInt("search.horizontal-range.end", 8000);
        worldOverworld = config.getString("worlds.overworld", "");
        worldNether = config.getString("worlds.nether", "");
        worldEnd = config.getString("worlds.end", "");
        blocksPerTick = Math.max(100, config.getInt("generation.blocks-per-tick", 1200));
        foundationDepth = Math.max(0, config.getInt("generation.foundation-depth", 12));
        rewardPerCastle = castles.getInt("rewards.per-castle", 10000);
        discoveryTitle = castles.getString("discovery.title", "<gold>Castle Discovered");
        discoverySubtitle = castles.getString("discovery.subtitle", "<yellow>+10,000 soldiers");
        discoverySound = castles.getString("discovery.sound", "UI_TOAST_CHALLENGE_COMPLETE");
        discoveryParticle = castles.getString("discovery.particle", "END_ROD");
        particleCount = castles.getInt("discovery.particle-count", 48);
        loot = readLoot(castles);
        maxVisiblePerPlayer = army.getInt("limits.max-visible-per-player", 12);
        maxGuardsPerPlayer = army.getInt("limits.max-guards-per-player", 8);
        maxActivePerWorld = army.getInt("limits.max-active-per-world", 100);
        maxActiveServer = army.getInt("limits.max-active-server", 180);
        visibleFollow = army.getInt("visible-squad.follow", 10);
        visibleDefend = army.getInt("visible-squad.defend", 8);
        visibleAttack = army.getInt("visible-squad.attack", 10);
        visibleMine = army.getInt("visible-squad.mine", 4);
        visibleBuild = army.getInt("visible-squad.build", 4);
        assignedFollow = army.getInt("assigned-squad.follow", 12);
        assignedDefend = army.getInt("assigned-squad.defend", 8);
        assignedAttack = army.getInt("assigned-squad.attack", 12);
        assignedMine = army.getInt("assigned-squad.mine", 4000);
        assignedBuild = army.getInt("assigned-squad.build", 2000);
        resumeDefense = army.getBoolean("tasks.resume-defense-on-join", true);
        resumeFollow = army.getBoolean("tasks.resume-follow-on-join", false);
        keepGuardsOnQuit = army.getBoolean("tasks.keep-guards-when-owner-quits", true);
        mineCycleSeconds = Math.max(1, army.getInt("tasks.mine-cycle-seconds", 5));
        mineMaxItems = army.getInt("tasks.mine-max-items-per-cycle", 24);
        simulateMining = army.getBoolean("tasks.simulate-mining", true);
        realMineBlocks = army.getInt("tasks.real-mine-blocks-per-cycle", 3);
        buildBlocksPerCycle = Math.max(1, army.getInt("tasks.build-blocks-per-cycle", 8));
        refusePlayerBuilds = army.getBoolean("tasks.refuse-player-builds", true);
        selectionTimeoutSeconds = army.getInt("tasks.selection-timeout-seconds", 90);
        followTeleportDistance = army.getInt("follow.teleport-distance", 30);
        followSpeed = army.getDouble("follow.walk-speed", 1.15);
        defaultRadius = army.getInt("defense.default-radius", 24);
        minRadius = army.getInt("defense.min-radius", 8);
        maxRadius = army.getInt("defense.max-radius", 64);
        defenseLeash = army.getBoolean("defense.leash", true);
        attackOrderDistance = army.getInt("attack.max-order-distance", 48);
        attackLeash = army.getInt("attack.leash-distance", 56);
        ironChance = army.getDouble("mining.iron-chance", 0.12);
        goldChance = army.getDouble("mining.gold-chance", 0.04);
        realBreakable = readMaterials(army.getStringList("mining.real-breakable"));
        attackDamage = combat.getDouble("damage.attack-damage", 3.0);
        attackKnockback = combat.getDouble("damage.attack-knockback", 0.1);
        knockbackResistance = combat.getDouble("damage.knockback-resistance", 0.85);
        maxHealth = combat.getDouble("damage.max-health", 30.0);
        movementSpeed = combat.getDouble("damage.movement-speed", 0.28);
        followRange = combat.getDouble("damage.follow-range", 28.0);
        protectOwner = combat.getBoolean("rules.protect-owner", true);
        protectTrusted = combat.getBoolean("rules.protect-trusted", true);
        respectWorldPvp = combat.getBoolean("rules.respect-world-pvp", true);
        respectWorldGuard = combat.getBoolean("rules.respect-worldguard", true);
        ignoreCreative = combat.getBoolean("rules.ignore-creative", true);
        hitDelayMs = combat.getLong("rules.per-target-hit-delay-ms", 400L);
    }

    public static Settings load(JavaPlugin plugin) {
        plugin.saveDefaultConfig();
        saveResource(plugin, "castles.yml");
        saveResource(plugin, "army.yml");
        saveResource(plugin, "combat.yml");
        plugin.reloadConfig();
        return new Settings(
                plugin.getConfig(),
                YamlConfiguration.loadConfiguration(new File(plugin.getDataFolder(), "castles.yml")),
                YamlConfiguration.loadConfiguration(new File(plugin.getDataFolder(), "army.yml")),
                YamlConfiguration.loadConfiguration(new File(plugin.getDataFolder(), "combat.yml"))
        );
    }

    public int minSpawn(Realm realm) {
        return switch (realm) {
            case OVERWORLD -> minSpawnOverworld;
            case NETHER -> minSpawnNether;
            case END -> minSpawnEnd;
        };
    }

    public int horizontalRange(Realm realm) {
        return switch (realm) {
            case OVERWORLD -> rangeOverworld;
            case NETHER -> rangeNether;
            case END -> rangeEnd;
        };
    }

    public String forcedWorld(Realm realm) {
        return switch (realm) {
            case OVERWORLD -> worldOverworld;
            case NETHER -> worldNether;
            case END -> worldEnd;
        };
    }

    public int visibleFor(String role) {
        return switch (role) {
            case "defend" -> visibleDefend;
            case "attack" -> visibleAttack;
            case "mine" -> visibleMine;
            case "build" -> visibleBuild;
            default -> visibleFollow;
        };
    }

    public int assignedFor(String role) {
        return switch (role) {
            case "defend" -> assignedDefend;
            case "attack" -> assignedAttack;
            case "mine" -> assignedMine;
            case "build" -> assignedBuild;
            default -> assignedFollow;
        };
    }

    private static void saveResource(JavaPlugin plugin, String name) {
        File file = new File(plugin.getDataFolder(), name);
        if (!file.exists()) {
            plugin.saveResource(name, false);
        }
    }

    private static Map<Realm, List<ItemStack>> readLoot(FileConfiguration castles) {
        Map<Realm, List<ItemStack>> map = new EnumMap<>(Realm.class);
        for (Realm realm : Realm.values()) {
            List<ItemStack> items = new ArrayList<>();
            List<Map<?, ?>> rows = castles.getMapList("loot." + realm.id);
            for (Map<?, ?> row : rows) {
                Object item = row.get("item");
                Object amount = row.get("amount");
                if (item == null) {
                    continue;
                }
                Material material = Material.matchMaterial(String.valueOf(item));
                if (material == null || material.isAir()) {
                    continue;
                }
                int count = amount instanceof Number number ? number.intValue() : 1;
                items.add(new ItemStack(material, Math.max(1, Math.min(material.getMaxStackSize(), count))));
            }
            map.put(realm, List.copyOf(items));
        }
        return map;
    }

    private static Set<Material> readMaterials(List<String> names) {
        Set<Material> materials = new HashSet<>();
        if (names == null || names.isEmpty()) {
            return materials;
        }
        for (String name : names) {
            Material material = Material.matchMaterial(name.toUpperCase(Locale.ROOT));
            if (material != null) {
                materials.add(material);
            }
        }
        return materials;
    }

    public static int artificialScore(org.bukkit.World world, int x, int y, int z) {
        int score = 0;
        for (int dx = -24; dx <= 24; dx += 4) {
            for (int dz = -24; dz <= 24; dz += 4) {
                for (int dy = -3; dy <= 4; dy += 2) {
                    Material material = world.getBlockAt(x + dx, y + dy, z + dz).getType();
                    if (isArtificial(material)) {
                        score++;
                    }
                }
            }
        }
        return score;
    }

    public static boolean isArtificial(Material material) {
        if (material == null || material.isAir()) {
            return false;
        }
        String name = material.name();
        return name.contains("BED") || name.contains("DOOR") || name.contains("SHULKER")
                || material == Material.CHEST || material == Material.TRAPPED_CHEST || material == Material.BARREL
                || material == Material.FURNACE || material == Material.BLAST_FURNACE || material == Material.SMOKER
                || material == Material.CRAFTING_TABLE || material == Material.ENCHANTING_TABLE
                || material == Material.ANVIL || material == Material.CHIPPED_ANVIL || material == Material.DAMAGED_ANVIL
                || material == Material.BEACON || material == Material.BREWING_STAND || material == Material.CARTOGRAPHY_TABLE
                || material == Material.LECTERN || material == Material.LOOM || material == Material.STONECUTTER;
    }
}
