package net.nexora.army.model;

public record Pos(int x, int y, int z) {
}
