package net.nexora.army.castle;

import net.nexora.army.model.Pos;
import net.nexora.army.model.Realm;

import java.util.List;

public final class CastleBlueprints {
    private CastleBlueprints() {
    }

    public static StructurePlan castle(Realm realm) {
        return switch (realm) {
            case OVERWORLD -> OverworldCastle.create();
            case NETHER -> NetherFortress.create();
            case END -> EndCitadel.create();
        };
    }

    public static StructurePlan template(String id) {
        return switch (id) {
            case "watchtower" -> watchtower();
            case "wall" -> wall();
            case "barracks" -> barracks();
            case "chapel" -> chapel();
            default -> null;
        };
    }

    public static List<String> templateIds() {
        return List.of("watchtower", "wall", "barracks", "chapel");
    }

    private static StructurePlan watchtower() {
        Brush brush = new Brush();
        brush.tower(0, 0, 10, 2, "stone_bricks", "stone_brick_slab[type=bottom]", "stone_brick_stairs", "stone_bricks", "torch");
        brush.air(0, 1, 2, 0, 2, 2);
        return StructurePlan.of("Watchtower", brush, new Pos(0, 1, 0), "torch", List.of());
    }

    private static StructurePlan wall() {
        Brush brush = new Brush();
        brush.walls(0, 0, 0, 16, 5, 2, "stone_bricks");
        brush.fill(0, 0, 0, 16, 0, 2, "stone_bricks");
        brush.merlons(0, 6, 0, 16, 2, "stone_bricks");
        brush.air(7, 1, 0, 9, 3, 2);
        return StructurePlan.of("Curtain Wall", brush, new Pos(8, 1, 1), "air", List.of());
    }

    private static StructurePlan barracks() {
        Brush brush = new Brush();
        brush.hollow(0, 0, 0, 12, 5, 8, "spruce_planks");
        brush.air(1, 1, 1, 11, 4, 7);
        brush.air(5, 1, 0, 7, 2, 0);
        brush.fill(0, 5, 0, 12, 5, 8, "spruce_slab[type=bottom]");
        brush.fill(2, 1, 6, 3, 1, 7, "oak_planks");
        brush.fill(9, 1, 6, 10, 1, 7, "oak_planks");
        return StructurePlan.of("Barracks", brush, new Pos(6, 1, 4), "air", List.of());
    }

    private static StructurePlan chapel() {
        Brush brush = new Brush();
        brush.hollow(0, 0, 0, 10, 7, 8, "stone_bricks");
        brush.air(1, 1, 1, 9, 6, 7);
        brush.air(4, 1, 0, 6, 3, 0);
        brush.squareRoof(5, 4, 8, 4, "stone_brick_stairs", "stone_bricks");
        brush.set(5, 1, 6, "bell[attachment=floor,facing=south]");
        brush.fill(5, 1, 2, 5, 1, 5, "red_carpet");
        return StructurePlan.of("Chapel", brush, new Pos(5, 1, 6), "bell", List.of());
    }
}
