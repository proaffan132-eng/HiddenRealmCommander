package net.nexora.army.castle;

import net.nexora.army.model.Pos;

import java.util.List;

/** Ancient Kingdom: stone curtain walls, corner bastions, gatehouse, keep, and a buried treasury. */
public final class OverworldCastle {
    private OverworldCastle() {
    }

    public static StructurePlan create() {
        Brush brush = new Brush();
        String wall = "stone_bricks";
        String moss = "mossy_stone_bricks";
        String cracked = "cracked_stone_bricks";
        String deep = "deepslate_bricks";
        String slab = "stone_brick_slab[type=bottom]";
        String stairs = "dark_oak_stairs";
        String wood = "dark_oak_planks";

        brush.fill(-40, -3, -40, 40, -1, 40, deep);
        brush.fill(-34, 0, -34, 34, 0, 34, "grass_block");
        for (int i = -34; i <= 34; i++) {
            brush.fill(-2, 0, i, 2, 0, i, "gravel");
            brush.fill(i, 0, -2, i, 0, 2, "gravel");
        }
        brush.air(-33, 1, -33, 33, 14, 33);

        brush.walls(-36, 0, -36, 36, 7, 36, wall);
        brush.walls(-35, 0, -35, 35, 6, 35, wall);
        for (int t = -36; t <= 36; t += 5) {
            brush.fill(t, 0, -36, t, 7, -35, moss);
            brush.fill(t, 0, 35, t, 7, 36, moss);
            brush.fill(-36, 0, t, -35, 7, t, cracked);
            brush.fill(35, 0, t, 36, 7, t, cracked);
        }
        brush.merlons(-36, 8, -36, 36, 36, wall);
        brush.fill(-34, 7, -34, 34, 7, -33, slab);
        brush.fill(-34, 7, 33, 34, 7, 34, slab);
        brush.fill(-34, 7, -34, -33, 7, 34, slab);
        brush.fill(33, 7, -34, 34, 7, 34, slab);

        brush.air(-3, 1, 34, 3, 5, 37);
        brush.tower(-36, -36, 16, 4, wall, slab, stairs, wood, "blue_banner[rotation=8]");
        brush.tower(36, -36, 16, 4, wall, slab, stairs, wood, "blue_banner[rotation=0]");
        brush.tower(-36, 36, 16, 4, wall, slab, stairs, wood, "white_banner[rotation=8]");
        brush.tower(36, 36, 16, 4, wall, slab, stairs, wood, "white_banner[rotation=0]");
        brush.tower(0, -36, 13, 3, wall, slab, stairs, wood, "blue_banner[rotation=8]");
        brush.tower(-36, 0, 12, 3, wall, slab, stairs, wood, "white_banner[rotation=4]");
        brush.tower(36, 0, 12, 3, wall, slab, stairs, wood, "white_banner[rotation=12]");

        brush.hollow(-8, 0, 32, 8, 12, 44, wall);
        brush.air(-3, 1, 32, 3, 5, 44);
        brush.fill(-8, 0, 32, 8, 0, 44, "gravel");
        brush.fill(-3, 6, 36, 3, 7, 36, "iron_bars[east=true,west=true]");
        brush.fill(-8, 11, 32, 8, 11, 44, slab);
        brush.merlons(-8, 12, 32, 8, 44, wall);
        brush.set(0, 13, 44, "lantern[hanging=false]");
        brush.set(-7, 8, 38, "wall_torch[facing=east]");
        brush.set(7, 8, 38, "wall_torch[facing=west]");

        brush.hollow(-14, 0, -16, 14, 14, 14, wall);
        brush.fill(-14, 0, -16, 14, 0, 14, "stone_bricks");
        brush.air(-13, 1, -15, 13, 12, 13);
        brush.air(-2, 1, 14, 2, 4, 14);
        brush.fill(-13, 8, -15, 13, 8, 13, "smooth_stone_slab[type=top]");
        brush.air(-2, 9, 14, 2, 11, 14);
        for (int y = 1; y <= 11; y++) {
            brush.set(12, y, 0, "ladder[facing=west]");
        }
        brush.fill(0, 1, -8, 0, 1, 12, "red_carpet");
        brush.set(0, 1, -11, "quartz_stairs[facing=south,half=bottom,shape=straight]");
        brush.set(0, 2, -12, "gold_block");
        brush.fill(-10, 1, -12, -8, 6, -10, wall);
        brush.fill(8, 1, -12, 10, 6, -10, wall);
        brush.fill(-6, 1, 6, -5, 6, 7, "bookshelf");
        brush.fill(5, 1, 6, 6, 6, 7, "bookshelf");
        brush.set(-9, 1, 6, "crafting_table");
        brush.set(9, 1, 6, "anvil[facing=north]");
        brush.fill(-1, 9, -6, 1, 9, -4, "red_carpet");
        brush.set(0, 10, -5, "lantern[hanging=false]");
        for (int y = 2; y <= 6; y += 2) {
            brush.set(-14, y, -4, "glass_pane[north=true,south=true]");
            brush.set(-14, y, 4, "glass_pane[north=true,south=true]");
            brush.set(14, y, -4, "glass_pane[north=true,south=true]");
            brush.set(14, y, 4, "glass_pane[north=true,south=true]");
            brush.set(-4, y, -16, "glass_pane[east=true,west=true]");
            brush.set(4, y, -16, "glass_pane[east=true,west=true]");
        }
        brush.squareRoof(0, -1, 15, 8, stairs, wood);

        for (int step = 0; step <= 7; step++) {
            brush.air(-11, -step, -2 + step, -9, 1 - step, 0 + step);
            brush.set(-10, -step, -2 + step, "cobblestone_stairs[facing=south,half=bottom,shape=straight]");
        }
        brush.hollow(-8, -8, -18, 8, -3, -6, deep);
        brush.air(-7, -7, -17, 7, -4, -7);
        brush.fill(-8, -8, -18, 8, -8, -6, "polished_deepslate");
        brush.fill(-2, -7, -14, 2, -7, -9, "red_carpet");
        brush.set(0, -7, -12, "lodestone");
        brush.set(0, -6, -12, "lantern[hanging=false]");
        brush.set(0, -6, -16, "oak_wall_sign[facing=south]");
        Pos chestA = new Pos(-6, -7, -16);
        Pos chestB = new Pos(6, -7, -16);
        Pos chestC = new Pos(-6, -7, -8);
        Pos chestD = new Pos(6, -7, -8);
        brush.set(chestA.x(), chestA.y(), chestA.z(), "chest[facing=east,type=single]");
        brush.set(chestB.x(), chestB.y(), chestB.z(), "chest[facing=west,type=single]");
        brush.set(chestC.x(), chestC.y(), chestC.z(), "chest[facing=east,type=single]");
        brush.set(chestD.x(), chestD.y(), chestD.z(), "chest[facing=west,type=single]");
        brush.fill(-1, -7, -17, 1, -5, -17, "gold_block");

        brush.fill(-40, 1, -10, -36, 2, -9, "oak_leaves[persistent=true]");
        brush.air(-35, 1, -10, -33, 2, -9);
        brush.set(0, 1, 0, "water_cauldron");
        brush.set(0, 1, -28, "lantern[hanging=false]");
        brush.set(0, 1, 28, "lantern[hanging=false]");
        brush.set(-20, 1, 0, "lantern[hanging=false]");
        brush.set(20, 1, 0, "lantern[hanging=false]");
        brush.fill(-18, 1, -18, -16, 1, -16, "hay_block");
        brush.fill(16, 1, -18, 18, 1, -16, "hay_block");

        return StructurePlan.of("Ancient Kingdom", brush, new Pos(0, -7, -12), "lodestone",
                List.of(chestA, chestB, chestC, chestD));
    }
}
