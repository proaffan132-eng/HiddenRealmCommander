# HiddenRealmCommander repair notes

This source repair addresses the startup blockers in the supplied archive:

- Adds the missing `net.nexora.army.ArmyPlugin` entry point and wires up the database, settings, soldier manager, castle service, commands, listeners, and repeating army tick.
- Adds the missing `ArmyMenus` inventory GUI used by `ArmyService`.
- Adds the relic item to castle chests and implements one-time per-player relic claiming for the configured soldier reward.
- Aligns the plugin API declaration with Paper 1.21 (`api-version: '1.21'`).

## Build

Build with Java 21 and Gradle 8.10+:

```bash
gradle build
```

The shaded plugin should be created at `build/libs/HiddenRealmCommander.jar`.

The GitHub Actions workflow in `.github/workflows/build.yml` also builds the JAR and uploads it as an artifact when run on GitHub.

**Important:** this environment has Java 21 but no Gradle installation and cannot reach the Gradle distribution host, so a compiled JAR could not be verified here. Treat this as a repaired source project until the Gradle build succeeds.
